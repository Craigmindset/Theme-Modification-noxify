<?php
if (!defined('ABSPATH')) exit; // No access of directly access

class Noxiy_Addons
{

	private static $_instance = null;

	public static function instance()
	{
		if (is_null(self::$_instance)) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	public function init()
	{
		// Register widgets
		add_action('elementor/widgets/register', [$this, 'noxiy_toolkit_register_widgets']);
	}

	public function noxiy_toolkit_register_widgets()
	{

	// Its is now safe to include Widgets files

		require_once('widget/slider-banner.php');
		require_once('widget/image.php');
		require_once('widget/subtitle.php');
		require_once('widget/text-slide.php');
		require_once('widget/button.php');
		require_once('widget/counter.php');
		require_once('widget/services.php');
		require_once('widget/team.php');
		require_once('widget/skillbar.php');
		require_once('widget/video-icon.php');
		require_once('widget/faq.php');
		require_once('widget/step.php');
		require_once('widget/portfolio.php');
		require_once('widget/blog-grid.php');
		require_once('widget/price-item.php');
		require_once('widget/testimonial.php');
		require_once('widget/price-tab.php');
		require_once('widget/team-single.php');
		require_once('widget/main-header.php');
		require_once('widget/contact-info.php');
		require_once('widget/tab-from.php');
		require_once('widget/features-section.php');
	
	// Theme Builder

		require_once('widget/theme-builder/nav-menu.php');
		require_once('widget/theme-builder/logo.php');
		require_once('widget/theme-builder/search.php');
		require_once('widget/theme-builder/offcanvas.php');
	;


	}
}

// Instantiate Plugin Class
Noxiy_Addons::instance()->init();