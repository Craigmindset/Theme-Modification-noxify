<?php

namespace Elementor;

use Elementor\Utils;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

if (!defined('ABSPATH'))
    exit;

class Portfolio_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'portfolio_noxiy';
    }

    public function get_title()
    {
        return esc_html__('Portfolio - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'Project', 'Portfolio', 'Home'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('Style & Options', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label' => esc_html__('Select a Style', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Style 01', 'noxiy-toolkit'),
                    'design-2' => esc_html__('Style 02', 'noxiy-toolkit'),
                    'design-3' => esc_html__('Style 03', 'noxiy-toolkit'),
                    'design-4' => esc_html__('Style 04', 'noxiy-toolkit'),
                    'design-5' => esc_html__('Style 05', 'noxiy-toolkit'),
                ],
                'default' => 'design-1',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'enable_slider',
            [
                'label' => esc_html__('Enable Slider', 'noxiy-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'noxiy-toolkit'),
                'label_off' => esc_html__('No', 'noxiy-toolkit'),
                'return_value' => 'yes',
                'default' => 'no',
                'condition' => [
                    'select_design' => ['design-3'],
                ],
            ]
        );

        $this->add_control(
            'columns_desktop',
            [
                'label' => esc_html__('Columns On Desktop', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'col-xl-6' => esc_html__('Column 2', 'noxiy-toolkit'),
                    'col-xl-4' => esc_html__('Column 3', 'noxiy-toolkit'),
                    'col-xl-3' => esc_html__('Column 4', 'noxiy-toolkit'),
                ],
                'default' => 'col-xl-4',
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-3','design-4','design-5'],
                ],
            ]
        );

        $this->add_control(
            'columns_tab',
            [
                'label' => esc_html__('Columns On Tablet', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'col-lg-12' => esc_html__('1 Column', 'noxiy-toolkit'),
                    'col-lg-6' => esc_html__('2 Column', 'noxiy-toolkit'),
                ],
                'default' => 'col-lg-6',
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-3','design-4','design-5'],
                ],
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Portfolio Content', 'noxiy-toolkit'),
            ]
        );


        $content = new Repeater();


        $content->add_control(
            'image',
            [
                'label' => esc_html__('Choose Image', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        $content->add_control(
            'icon',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fa fa-star',
                    'library' => 'brands',
                ],
            ]
        );

        $content->add_control(
            'number',
            [
                'label' => esc_html__('Number', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $content->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $content->add_control(
            'description',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
            ]
        );

        $content->add_control(
            'btn_text',
            [
                'label' => esc_html__('Button Text', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $content->add_control(
            'item_url',
            [
                'label' => esc_html__('Item URL', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );



        $this->add_control(
            'content_items',
            [
                'label' => esc_html__('Content Items', 'noxiy-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $content->get_controls(),
                'default' => [
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'number' => esc_html__('01', 'noxiy-toolkit'),
                        'title' => esc_html__('Wellness Program', 'noxiy-toolkit'),
                        'description' => esc_html__('Our Specialty Care program..', 'noxiy-toolkit'),
                        'btn_text' => esc_html__('Read More', 'noxiy-toolkit'),
                        'item_url' => esc_attr__('http://google.com', 'noxiy-toolkit'),
                    ],

                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'number' => esc_html__('02', 'noxiy-toolkit'),
                        'title' => esc_html__('Specialty Care', 'noxiy-toolkit'),
                        'description' => esc_html__('Our Specialty Care program..', 'noxiy-toolkit'),
                        'btn_text' => esc_html__('Read More', 'noxiy-toolkit'),
                        'item_url' => esc_attr__('http://google.com', 'noxiy-toolkit'),
                    ],
                ],

                'title_field' => '{{{ title }}}',
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'portfolio_content_style',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'portfolio_number',
			[
				'label' => esc_html__( 'Subtitle', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
		);
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'portfolio_number_typography',
				'selector' => '{{WRAPPER}} .portfolio__four-item-inner-content-top span,
				{{WRAPPER}} .portfolio__two-item-image-content span,
				{{WRAPPER}} .project__one-item-content span,
				{{WRAPPER}} .portfolio__three-item-content span,
				{{WRAPPER}} .portfolio__one-item-content-right span',
			]
		);
        $this->add_control(
            'portfolio_number_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio__four-item-inner-content-top span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .portfolio__one-item-content-right span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .project__one-item-content span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .portfolio__three-item-content span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .portfolio__two-item-image-content span' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_opacity',
            [
                'label' => esc_html__('Opacity', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
					'unit' => 'px',
					'size' => 0.1,
				],
                'selectors' => [
                    '{{WRAPPER}} .portfolio__four-item-inner-content-top span' => 'opacity: {{SIZE}};',
                ],
                'condition' => [
                    'select_design' => ['design-1'],
                ]
            ]
        );
		$this->add_control(
			'portfolio_title',
			[
				'label' => esc_html__( 'Title', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
		);
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'portfolio_typography',
				'selector' => '{{WRAPPER}} .portfolio__four-item-inner-content-top h4,
                {{WRAPPER}} .portfolio__four-item-inner-content-btn h4,
                {{WRAPPER}} .portfolio__one-item-content-right h4,
                {{WRAPPER}} .portfolio__three-item-content h4,
                {{WRAPPER}} .project__one-item-content h4,
                {{WRAPPER}} .portfolio__two-item-image-content h4',
			]
		);
        $this->add_control(
            'portfolio_title_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio__four-item-inner-content-top h4' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .project__one-item-content h4' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .portfolio__one-item-content-right h4' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .portfolio__three-item-content h4' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .portfolio__two-item-image-content h4' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'portfolio_hover_color',
            [
                'label' => esc_html__('Hover Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio__one-item-content-right h4 a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .project__one-item-content h4 a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .portfolio__three-item-content h4 a:hover' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-1','design-2','design-3','design-5'],
                ]
            ]
        );
		$this->add_control(
			'portfolio_description',
			[
				'label' => esc_html__( 'Description', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
                'condition' => [
                    'select_design' => ['design-1'],
                ]
			]
		);
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'portfolio_description_typography',
				'selector' => '{{WRAPPER}} .portfolio__four-item-inner-content-top p',
                'condition' => [
                    'select_design' => ['design-1'],
                ]
			]
		);
        $this->add_control(
            'portfolio_description_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio__four-item-inner-content-top p' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-1'],
                ]
            ]
        );

        $this->add_control(
            'portfolio_background_color',
            [
                'label' => esc_html__('Item Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio__four-item-inner-content::after' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .portfolio__one-item-content' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .portfolio__three-item-content.vertical' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-1','design-2','design-3'],
                ]
            ]
        );

        $this->add_control(
            'portfolio_linear_color',
            [
                'label' => esc_html__('Linear Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio__two-item-image::after' => 'background: linear-gradient(180deg, rgba(249, 77, 29, 0) 0%,{{VALUE}} 85.11%)',
                ],
                'condition' => [
                    'select_design' => ['design-4'],
                ]
            ]
        );

   

        $this->add_control(
            'portfolio_content_background',
            [
                'label' => esc_html__('Content Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio__three-item-content' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .project__one-item-content' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-2','design-3','design-5'],
                ]
            ]
        );

        $this->add_control(
            'portfolio_shape_background',
            [
                'label' => esc_html__('Shape Content', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project__one-item-content::after' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .project__one-item-content::before' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-5'],
                ]
            ]
        );

        $this->add_responsive_control(
			'portfolio_item_padding',
			[
				'type' => Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Padding', 'noxiy-toolkit' ),
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .portfolio__four-item-inner-content-top' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .project__one-item-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .portfolio__three-item-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'separator' => 'before',
                'condition' => [
                    'select_design' => ['design-2'],
                ]
			]
		);

        $this->add_responsive_control(
            'portfolio_item_radius',
            [
                'type' => Controls_Manager::DIMENSIONS,
                'label' => esc_html__('Border Radius', 'noxiy-toolkit'),
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .project__one-item-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .portfolio__three-item-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
                'condition' => [
                    'select_design' => ['design-2'],
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'portfolio_icon_style',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'select_design' => ['design-1','design-2','design-3','design-4'],
                ]
            ]
        );

        $this->add_control(
            'portfolio_icon_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio__four-item-inner-content-top i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .portfolio__three-item-content-icon a i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .portfolio__one-item-content-left i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .portfolio__one-item-content-left' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .portfolio__two-item-image-content > a i' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'portfolio_icon_background',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio__three-item-content-icon a i' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .portfolio__one-item-content-left i' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .portfolio__two-item-image-content > a i' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-2','design-3','design-4','design-5'],
                ]
            ]
        );

        $this->add_responsive_control(
            'portfolio_icon_size',
            [
                'label' => esc_html__('Font Size', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .portfolio__four-item-inner-content-top i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .portfolio__three-item-content-icon a i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .portfolio__one-item-content-left i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .portfolio__two-item-image-content > a i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'portfolio_icon_width',
            [
                'label' => esc_html__('Max Width', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .portfolio__three-item-content-icon a i' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .portfolio__one-item-content-left i' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .portfolio__two-item-image-content > a i' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'select_design' => ['design-2','design-3','design-4','design-5'],
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'portfolio_button_style',
            [
                'label' => esc_html__('Button', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'select_design' => ['design-1','design-6'],
                ]
            ]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'portfolio_btn_typography',
				'selector' => '{{WRAPPER}} .portfolio__four-item-inner-content-btn span',
			]
		);

        $this->add_control(
            'portfolio_button_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio__four-item-inner-content-btn span' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'portfolio_button_background',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio__four-item-inner-content-btn' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'portfolio_button_hover_background',
            [
                'label' => esc_html__('Hover Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio__four-item.active .portfolio__four-item-inner-content-btn' => 'background: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_responsive_control(
			'portfolio_button_padding',
			[
				'type' => Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Padding', 'noxiy-toolkit' ),
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .portfolio__four-item-inner-content-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'separator' => 'before',
			]
		);
        $this->end_controls_section();


    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $blog_column = $settings['columns_desktop'] . ' ' . $settings['columns_tab'];

?>

        <?php if ('design-1' === $settings['select_design']) : ?>

            <!-- Portfolio Area Start -->
            <div class="portfolio__four dark__image">
                <?php foreach ($settings['content_items'] as $keys => $item) : ?>
                    <div class="portfolio__four-item <?php echo $keys === 1 ? 'active' : ''; ?> ">
                        <div class="portfolio__four-item-image" data-background="<?php echo esc_url($item['image']['url']) ?>"></div>
                        <div class="portfolio__four-item-inner">
                            <div class="portfolio__four-item-inner-content">
                                <div class="portfolio__four-item-inner-content-top">
                                    <span>
                                        <?php echo esc_html($item['number']); ?>
                                    </span>
                                    <i class="<?php echo esc_attr($item['icon']['value']); ?>"></i>
                                    <h4><a href="<?php echo esc_url($item['item_url']); ?>"><?php echo esc_html($item['title']); ?></a>
                                    </h4>
                                    <p>
                                        <?php echo esc_html($item['description']); ?>
                                    </p>
                                </div>
                                <div class="portfolio__four-item-inner-content-btn">
                                    <h4>
                                        <?php echo esc_html($item['title']); ?>
                                    </h4>
                                    <span><a href="<?php echo esc_url($item['item_url']); ?>"><?php echo esc_html($item['btn_text']); ?></a></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <!-- Portfolio Area End -->

        <?php endif; ?>

        <?php if ('design-2' === $settings['select_design']) : ?>
            <!-- Portfolio Area Start -->
            <div class="portfolio__three">
                <div class="portfolio">
                    <?php foreach ($settings['content_items'] as $keys => $item) : ?>
                        <div class="portfolio__three-item <?php echo $keys === 1 ? 'active' : ''; ?>">
                            <img src="<?php echo esc_url($item['image']['url']) ?>" alt="house-insurance">
                            <div class="portfolio__three-item-content vertical">
                                <div>
                                    <span><?php echo esc_html($item['description']); ?></span>
                                    <h4><a href="<?php echo esc_url($item['item_url']); ?>"><?php echo esc_html($item['title']); ?></a></h4>
                                </div>
                                <div class="portfolio__three-item-content-icon vertical">
                                    <a href="<?php echo esc_url($item['item_url']); ?>"><i class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a>
                                </div>
                            </div>
                            <div class="portfolio__three-item-content transition">
                                <div>
                                    <span><?php echo esc_html($item['description']); ?></span>
                                    <h4><a href="<?php echo esc_url($item['item_url']); ?>"><?php echo esc_html($item['title']); ?></a></h4>
                                </div>
                                <div class="portfolio__three-item-content-icon">
                                    <a href="<?php echo esc_url($item['item_url']); ?>"><i class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <!-- Portfolio Area End -->
        <?php endif; ?>

        <?php if ('design-3' === $settings['select_design']) : ?>
            <?php if ('yes' === $settings['enable_slider']) { ?>
                <!-- Portfolio Area Start -->
                <div class="portfolio__one">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-xl-12">
                                <div class="swiper portfolio__one-slider">
                                    <div class="swiper-wrapper">
                                        <?php foreach ($settings['content_items'] as $item) : ?>

                                            <div class="portfolio__one-item swiper-slide">
                                                <img src="<?php echo esc_url($item['image']['url']) ?>" alt="renters-insurance">
                                                <div class="portfolio__one-item-content">
                                                    <div class="portfolio__one-item-content-left">
                                                        <a href="<?php echo esc_url($item['item_url']); ?>"><i class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a>
                                                    </div>
                                                    <div class="portfolio__one-item-content-right">
                                                        <span><?php echo esc_html($item['description']); ?></span>
                                                        <h4><a href="<?php echo esc_url($item['item_url']); ?>"><?php echo esc_html($item['title']); ?></a></h4>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } else { ?>
                <!-- Portfolio Area Start -->
                <div class="portfolio__one">                   
                    <div class="container">
                    <div class="row">
                            <?php foreach ($settings['content_items'] as $item) : ?>
                                <div class="<?php echo esc_attr($blog_column); ?> mt-30">
                                    <div class="portfolio__one-item page">
                                        <img src="<?php echo esc_url($item['image']['url']) ?>" alt="<?php echo esc_html($item['title']); ?>">
                                        <div class="portfolio__one-item-content">
                                            <div class="portfolio__one-item-content-left">
                                                <a href="<?php echo esc_url($item['item_url']); ?>"><i class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a>
                                            </div>
                                            <div class="portfolio__one-item-content-right">
                                                <span><?php echo esc_html($item['description']); ?></span>
                                                <h4><a href="<?php echo esc_url($item['item_url']); ?>"><?php echo esc_html($item['title']); ?></a></h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            <?php endforeach; ?>
                        </div>                    
                    </div>                    
                </div>
                <!-- Portfolio Area End -->
            <?php } ?>
            <!-- Portfolio Area End -->
        <?php endif; ?>

    <?php if ('design-4' === $settings['select_design']) : ?>
    <!-- Portfolio Area Start -->
	<div class="portfolio__three-page">
        <div class="container">
		<div class="row">
            <?php foreach ($settings['content_items'] as $item) : ?>
				<div class="<?php echo esc_attr($blog_column); ?>">
					<div class="portfolio__two-item">
						<div class="portfolio__two-item-image">
							<img src="<?php echo esc_url($item['image']['url']) ?>" alt="<?php echo esc_html($item['title']); ?>">
							<div class="portfolio__two-item-image-content">
								<a href="<?php echo esc_url($item['item_url']); ?>"><i class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a>
								<span><?php echo esc_html($item['description']); ?></span>
								<h4><a href="<?php echo esc_url($item['item_url']); ?>"><?php echo esc_html($item['title']); ?></a></h4>
							</div>
						</div>
					</div>
				</div>
                <?php endforeach; ?>
			</div>
        </div>
    </div>
    <?php endif; ?>

    <?php if ('design-5' === $settings['select_design']) : ?>
	<!-- Portfolio Area Start -->
	    <div class="portfolio__one">
            <div class="row">
            <?php foreach ($settings['content_items'] as $item) : ?>
                <div class="<?php echo esc_attr($blog_column); ?> mt-25">
                    <div class="project__one-item">
                        <img class="img__full" src="<?php echo esc_url($item['image']['url']) ?>" alt="<?php echo esc_html($item['title']); ?>">
                        <div class="project__one-item-content">
                            <span><?php echo esc_html($item['description']); ?></span>
                            <h4><a href="<?php echo esc_url($item['item_url']); ?>"><?php echo esc_html($item['title']); ?></a></h4>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>

<?php
    }
}

Plugin::instance()->widgets_manager->register(new Portfolio_Noxiy);
