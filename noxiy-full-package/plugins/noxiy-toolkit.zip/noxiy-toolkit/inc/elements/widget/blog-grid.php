<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit;

class Blog_Grid_Noxiy extends Widget_Base
{


    public function get_name()
    {
        return 'blog_grid_noxiy';
    }


    public function get_title()
    {
        return esc_html__('Blog Grid - Noxiy', 'noxiy-toolkit');
    }


    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }


    public function get_categories()
    {
        return ['noxiy-toolkit'];
    }

    public function get_keywords()
    {
        return ['Noxiy', 'Toolkit', 'Blog', 'Grid'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('Style & Column', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label' => esc_html__('Select a Style', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Blog Style 01', 'noxiy-toolkit'),
                    'design-2' => esc_html__('Blog Style 02', 'noxiy-toolkit'),
                    'design-3' => esc_html__('Blog Style 03', 'noxiy-toolkit'),
                    'design-4' => esc_html__('Blog Style 04', 'noxiy-toolkit'),
                ],
                'default' => 'design-1',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'columns_desktop',
            [
                'label' => esc_html__('Columns On Desktop', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'col-xl-6' => esc_html__('Column 2', 'noxiy-toolkit'),
                    'col-xl-4' => esc_html__('Column 3', 'noxiy-toolkit'),
                    'col-xl-3' => esc_html__('Column 4', 'noxiy-toolkit'),
                ],
                'default' => 'col-xl-4',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'columns_tab',
            [
                'label' => esc_html__('Columns On Tablet', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'col-lg-12' => esc_html__('1 Column', 'noxiy-toolkit'),
                    'col-lg-6' => esc_html__('2 Column', 'noxiy-toolkit'),
                ],
                'default' => 'col-lg-6',
                'label_block' => true,
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'blog_query',
            [
                'label' => esc_html__('Blog Query', 'noxiy-toolkit'),
            ]
        );


        $this->add_control(
            'post_count',
            [
                'label' => esc_html__('Number Of Posts', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['count'],
                'range' => [
                    'count' => [
                        'min' => 2,
                        'max' => 15,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'count',
                    'size' => 3,
                ],
            ]
        );

        $this->add_control(
            'word_limit',
            [
                'label' => esc_html__('Content Word Limit', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['count'],
                'range' => [
                    'count' => [
                        'min' => 5,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'count',
                    'size' => 10,
                ],
            ]
        );

        $this->add_control(
            'category',
            [
                'label' => esc_html__('Categories', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'multiple' => true,
                'options' => noxiy_post_categories(),
            ]
        );

        $this->add_control(
            'blog_btn_text',
            [
                'label' => esc_html__('Blog Button', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Read More', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'author_text',
            [
                'label' => esc_html__('Author Text', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Post By', 'noxiy-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-4'],
                ],
            ]
        );

        $this->end_controls_section();












        $this->start_controls_section(
            'blog_item_style',
            [
                'label' => esc_html__('Item', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'blog_item_background',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog__three-item::before' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-3'],
                ]
            ]
        );

        $this->add_control(
            'blog_item_hover_background',
            [
                'label' => esc_html__('Hover Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog__three-item::after' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-3'],
                ]
            ]
        );

        $this->add_control(
            'blog_item_border',
            [
                'label' => esc_html__('Border Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog__two-item-content' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .blog__two-item-btn a' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .blog__one-item-content' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .blog__four-item' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .blog__four-item-content ul' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .blog__two-item-content-author-post-right a' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .blog__one-item-btn a' => 'border-color: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-1','design-2','design-4'],
                ]
            ]
        );


        $this->add_responsive_control(
			'blog_item_padding',
			[
				'type' => Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Padding', 'noxiy-toolkit' ),
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .blog__one-item-btn a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .blog__two-item-btn a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .blog__two-item-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .blog__one-item-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .blog__three-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'separator' => 'before',
                'condition' => [
                    'select_design' => ['design-2','design-3','design-4'],
                ]
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
            'blog_content_style',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs(
            'style_tabs'
        );
        $this->start_controls_tab(
            'style_normal_tab',
            [
                'label' => esc_html__('Normal', 'noxiy-toolkit'),
            ]
        );
		$this->add_control(
			'blog_title',
			[
				'label' => esc_html__( 'Title', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
		);
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'blog_typography',
				'selector' => '{{WRAPPER}} .blog__two-item-content h4,
                {{WRAPPER}} .blog__three-item h4,
                {{WRAPPER}} .blog__one-item-content h4,
				{{WRAPPER}} .blog__four-item-content h4',
			]
		);
        $this->add_control(
            'blog_title_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog__two-item-content h4' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog__three-item h4' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog__one-item-content h4' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog__four-item-content h4' => 'color: {{VALUE}}',
                ],
            ]
        );
		$this->add_control(
			'blog_description',
			[
				'label' => esc_html__( 'Description', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
                'condition' => [
                    'select_design' => ['design-1','design-2'],
                ]
			]
		);
		$this->add_control(
			'blog_author',
			[
				'label' => esc_html__( 'Author', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
                'condition' => [
                    'select_design' => ['design-3','design-4'],
                ]
			]
		);
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'blog_description_typography',
				'selector' => '{{WRAPPER}} .blog__three-item-author h6,
                {{WRAPPER}} .blog__two-item-content-author-post-title h6',
                'condition' => [
                    'select_design' => ['design-3','design-4'],
                ]
			]
		);
        $this->add_control(
            'blog_description_color',
            [
                'label' => esc_html__('Name Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog__two-item-content-author-post-title h6' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog__three-item-author h6' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-3','design-4'],
                ]
            ]
        );
        $this->add_control(
            'blog_author_color',
            [
                'label' => esc_html__('Hover Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog__three-item:hover .blog__three-item-author h6' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-3'],
                ]
            ]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'blog_description_typography_p',
				'selector' => '{{WRAPPER}} .blog__one-item-content p,
                {{WRAPPER}} .blog__four-item-content p',
                'condition' => [
                    'select_design' => ['design-1','design-2'],
                ]
			]
		);
        $this->add_control(
            'blog_description_color_p',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog__one-item-content p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog__four-item-content p' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-1','design-2'],
                ]
            ]
        );
		$this->add_control(
			'blog_meta',
			[
				'label' => esc_html__( 'Meta', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
		);
        $this->add_control(
            'blog_meta_background',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog__four-item-image-date span' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .blog__three-item-meta' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .blog__two-item-content-date' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .blog__one-item-image-date h5' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'blog_meta_typography',
				'selector' => '{{WRAPPER}} .blog__two-item-content-author-post-right a,
                {{WRAPPER}} .blog__three-item-meta ul li a,
                {{WRAPPER}} .blog__one-item-content-meta ul li a,
				{{WRAPPER}} .blog__four-item-content ul li',
			]
		);
        $this->add_control(
            'blog_meta_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog__two-item-content-author-post-right a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog__three-item-meta ul li a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog__one-item-content-meta ul li a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog__four-item-content ul li' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'blog_meta_icon_color',
            [
                'label' => esc_html__('Icon Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog__three-item-meta ul li a i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog__one-item-content-meta ul li a i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog__four-item-content ul li i' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-1','design-2','design-3'],
                ]
            ]
        );
        $this->add_responsive_control(
            'meta_icon_space',
            [
                'label' => esc_html__('Gap', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'default' => [
					'unit' => 'px',
					'size' => 8,
				],
                'selectors' => [
                    '{{WRAPPER}} .blog__three-item-meta ul li a' => 'margin-right: {{SIZE}}{{UNIT}};padding-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .blog__one-item-content-meta ul li a' => 'margin-right: {{SIZE}}{{UNIT}};padding-right: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'select_design' => ['design-2','design-3'],
                ]
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'style_hover_tab',
            [
                'label' => esc_html__('Hover', 'noxiy-toolkit'),
            ]
        );
        $this->add_control(
			'blog_title_hover',
			[
				'label' => esc_html__( 'Title', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
		);
        $this->add_control(
            'blog_title_color_hover',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog__three-item:hover h4 a' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-3'],
                ]
            ]
        );
        $this->add_control(
            'blog_text_color_hover',
            [
                'label' => esc_html__('Hover Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog__three-item:hover h4 a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog__two-item-content h4 a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog__one-item-content h4 a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog__four-item-content h4 a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
			'blog_meta_hover',
			[
				'label' => esc_html__( 'Meta', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
                'condition' => [
                    'select_design' => ['design-2','design-3'],
                ]
			]
		);
        $this->add_control(
            'blog_hover_meta_background',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog__three-item:hover .blog__three-item-meta' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-3'],
                ]
            ]
        );
        $this->add_control(
            'hover_meta_color',
            [
                'label' => esc_html__('Hover Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog__one-item-content-meta ul li a:hover' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-2'],
                ]
            ]
        );
        $this->add_control(
            'blog_hover_meta_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog__three-item:hover .blog__three-item-meta ul li a' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-3'],
                ]
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();    
        $this->end_controls_section();

        $this->start_controls_section(
            'blog_button_style',
            [
                'label' => esc_html__('Button', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'blog_btn_typography',
				'selector' => '{{WRAPPER}} .blog__four-item-content > a,
				{{WRAPPER}} .blog__one-item-btn a,
				{{WRAPPER}} .blog__two-item-btn a,
				{{WRAPPER}} .blog__three-item-btn a',
			]
		);

        $this->add_control(
            'blog_button_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog__four-item-content > a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog__three-item-btn a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog__one-item-btn a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog__two-item-btn a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'blog_button_hover_color',
            [
                'label' => esc_html__('Hover Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog__two-item:hover .blog__two-item-btn a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog__three-item:hover .blog__three-item-btn a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog__one-item:hover .blog__one-item-btn a' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-2','design-3','design-4'],
                ]
            ]
        );

        $this->add_control(
            'blog_button_background',
            [
                'label' => esc_html__('Hover Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog__one-item-btn a::after' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .blog__two-item-btn a::after' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-2','design-4'],
                ]
            ]
        );
        $this->end_controls_section();

















    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $blog_column = $settings['columns_desktop'] . ' ' . $settings['columns_tab'];

        if (!empty($settings['category'])) {
            $post_query = new \WP_Query(
                array(
                    'post_type' => 'post',
                    'post_status' => 'publish',
                    'posts_per_page' => $settings['post_count']['size'],
                    'ignore_sticky_posts' => 1,
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'category',
                            'terms' => $settings['category'],
                            'field' => 'slug',
                        )
                    )
                )
            );
        } else {

            $post_query = new \WP_Query(
                array(
                    'post_type' => 'post',
                    'post_status' => 'publish',
                    'posts_per_page' => $settings['post_count']['size'],
                    'ignore_sticky_posts' => 1,
                )
            );
        }

        ?>

        <?php if ('design-1' === $settings['select_design']): ?>
            <div class="blog__four">
                <div class="container">
                    <div class="row">
                        <?php while ($post_query->have_posts()):
                            $post_query->the_post(); ?>
                            <div class="<?php echo esc_attr($blog_column); ?>">
                                <div class="blog__four-item">
                                    <div class="blog__four-item-image">
                                        <img src="<?php the_post_thumbnail_url('large'); ?>"
                                            alt="<?php echo get_post_meta(get_post_thumbnail_id(), '_wp_attachment_image_alt', true); ?>">
                                        <div class="blog__four-item-image-date">
                                            <span>
                                                <?php echo get_the_date(); ?>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="blog__four-item-content">
                                        <ul>
                                            <li><i class="fal fa-user-circle"></i>
                                                <?php the_author(); ?>
                                            </li>
                                        </ul>
                                        <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                        <p>
                                            <?php echo wp_trim_words(get_the_content(), ($settings['word_limit']['size']), '...'); ?>
                                        </p>
                                        <a href="<?php the_permalink(); ?>"><?php echo esc_html($settings['blog_btn_text']); ?><i
                                                class="far fa-long-arrow-right"></i></a>
                                    </div>

                                </div>
                            </div>
                            <?php
                        endwhile;
                        wp_reset_query();
                        ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>


        <?php if ('design-2' === $settings['select_design']): ?>
            <div class="blog__one dark__image">
                <div class="container">
                    <div class="row">
                        <?php while ($post_query->have_posts()):
                            $post_query->the_post(); ?>
                            <div class="<?php echo esc_attr($blog_column); ?>">
                                <div class="blog__one-item">
                                    <div class="blog__one-item-image">
                                        <a href="<?php the_permalink(); ?>">
                                            <img src="<?php the_post_thumbnail_url('large'); ?>"
                                                alt="<?php echo get_post_meta(get_post_thumbnail_id(), '_wp_attachment_image_alt', true); ?>">
                                        </a>
                                        <div class="blog__one-item-image-date">
                                            <h5>
                                                <?php echo get_the_date('d') ?>
                                            </h5>
                                            <span>
                                                <?php echo get_the_date('M') ?>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="blog__one-item-content">
                                        <div class="blog__one-item-content-meta">
                                            <ul>
                                                <li><a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>"><i
                                                            class="far fa-user"></i>
                                                        <?php the_author(); ?>
                                                    </a></li>
                                                <li><a href="<?php the_permalink(); ?>"><i class="far fa-comment-dots"></i>
                                                        <?php noxiy_comments_count(); ?>
                                                    </a></li>
                                            </ul>
                                        </div>
                                        <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                        <p>
                                            <?php echo wp_trim_words(get_the_content(), ($settings['word_limit']['size']), '...'); ?>
                                        </p>
                                    </div>
                                    <div class="blog__one-item-btn">
                                        <a href="<?php the_permalink(); ?>"><?php echo esc_html($settings['blog_btn_text']); ?><span><i
                                                    class="far fa-long-arrow-right"></i></span></a>
                                    </div>
                                </div>
                            </div>
                            <?php
                        endwhile;
                        wp_reset_query();
                        ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>



        <?php if ('design-3' === $settings['select_design']): ?>

            <!-- Blog Area Start -->
            <div class="blog__three">
                <div class="container">
                    <div class="row">
                        <?php while ($post_query->have_posts()):
                            $post_query->the_post();
                            $thumbnail_url = get_the_post_thumbnail_url(get_the_ID(), 'large'); ?>
                            <div class="<?php echo esc_attr($blog_column); ?>">
                                <div class="blog__three-item" data-background="<?php echo $thumbnail_url; ?>">
                                    <div class="blog__three-item-meta">
                                        <ul>
                                            <li><a href="<?php the_permalink(); ?>"><i class="far fa-calendar-alt"></i>
                                                    <?php echo get_the_date(); ?>
                                                </a></li>
                                            <li><a href="<?php the_permalink(); ?>"><i class="far fa-comment-dots"></i>
                                                    <?php noxiy_comments_count(); ?>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                    <div class="blog__three-item-author">
                                        <?php echo get_avatar(get_the_author_meta('ID'), 80); ?>
                                        <h6>
                                            <?php echo get_the_author(); ?>
                                        </h6>
                                    </div>
                                    <div class="blog__three-item-btn">
                                        <a href="<?php the_permalink(); ?>"><?php echo esc_html($settings['blog_btn_text']); ?><i
                                                class="far fa-long-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                            <?php
                        endwhile;
                        wp_reset_query();
                        ?>
                    </div>
                </div>
            </div>
            <!-- Blog Area End -->
        <?php endif; ?>


        <?php if ('design-4' === $settings['select_design']): ?>
            <!-- Blog Area Start -->
            <div class="blog__two">
                <div class="container">
                    <div class="row">
                        <?php while ($post_query->have_posts()):
                            $post_query->the_post(); ?>
                            <div class="<?php echo esc_attr($blog_column); ?> lg-mb-30">
                                <div class="blog__two-item">
                                    <div class="blog__two-item-image">
                                        <img src="<?php the_post_thumbnail_url('large'); ?>"
                                            alt="<?php echo get_post_meta(get_post_thumbnail_id(), '_wp_attachment_image_alt', true); ?>">
                                    </div>
                                    <div class="blog__two-item-content">
                                        <div class="blog__two-item-content-date">
                                            <h3>
                                                <?php echo get_the_date('d') ?>
                                            </h3>
                                            <span>
                                                <?php echo get_the_date('M') ?>
                                                </p>
                                        </div>
                                        <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                        <div class="blog__two-item-content-author">
                                            <div class="blog__two-item-content-author-post">
                                                <div class="blog__two-item-content-author-post-image">
                                                    <?php echo get_avatar(get_the_author_meta('ID'), 80); ?>
                                                </div>
                                                <div class="blog__two-item-content-author-post-title">
                                                    <span>
                                                        <?php echo esc_html($settings['author_text']); ?>
                                                    </span>
                                                    <h6>
                                                        <?php echo get_the_author(); ?>
                                                    </h6>
                                                </div>
                                            </div>
                                            <div class="blog__two-item-content-author-post-right">
                                                <a href="<?php the_permalink(); ?>"><i class="fas fa-comment"></i>
                                                    <?php noxiy_comments_count(); ?>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="blog__two-item-btn">
                                        <a href="<?php the_permalink(); ?>"><?php echo esc_html($settings['blog_btn_text']); ?><i
                                                class="far fa-long-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                            <?php
                        endwhile;
                        wp_reset_query();
                        ?>

                    </div>
                </div>
            </div>
            <!-- Blog Area End -->
        <?php endif; ?>

        <?php
    }
}

Plugin::instance()->widgets_manager->register(new Blog_Grid_Noxiy);