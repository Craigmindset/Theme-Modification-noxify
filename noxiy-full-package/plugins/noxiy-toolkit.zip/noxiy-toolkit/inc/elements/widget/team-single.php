<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if (!defined('ABSPATH'))
    exit;

class Team_Single_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'team-single-noxiy';
    }

    public function get_title()
    {
        return esc_html__('Team Single - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-toolkit'];
    }

    public function get_keywords()
    {
        return ['noxiy', 'Toolkit', 'Team', 'Single'];
    }


    protected function register_controls()
    {
        $this->start_controls_section(
            'section_head',
            [
                'label' => esc_html__('Team Content', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'team_image',
            [
                'label' => esc_html__('Team Image', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'title_one',
            [
                'label' => esc_html__('Name', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Amelia Clover', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'sub_title',
            [
                'label' => esc_html__('Position', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Senior Advisor', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'section_content1',
            [
                'label' => esc_html__('Social Icon', 'noxiy-toolkit')
            ]
        );

        $social_item = new Repeater();

        $social_item->add_control(
            'icon',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fab fa-facebook-f',
                    'library' => 'brands',
                ],
            ]
        );

        $social_item->add_control(
            'link',
            [
                'label' => esc_html__('URL', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'social_media',
            [
                'label' => esc_html__('Social Icons', 'noxiy-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $social_item->get_controls(),
                'default' => [
                    [

                        'icon' => esc_html__('fab fa-facebook-f', 'noxiy-toolkit'),
                        'link' => esc_attr__('https://facebook.com', 'noxiy-toolkit'),
                    ],
                ],
                'title_field' => '{{{ icon }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_head1',
            [
                'label' => esc_html__('Contact Info', 'noxiy-toolkit'),
            ]
        );


        $contact_item = new Repeater();

        $contact_item->add_control(
            'contact_icon',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fa fa-phone',
                    'library' => 'solid',
                ],
            ]
        );

        $contact_item->add_control(
            'contact_name',
            [
                'label' => esc_html__('Name', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );


        $contact_item->add_control(
            'contact_info',
            [
                'label' => esc_html__('Details', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $contact_item->add_control(
            'contact_link',
            [
                'label' => esc_html__('URL', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'contact_list',
            [
                'label' => esc_html__('Contact Lists', 'noxiy-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $contact_item->get_controls(),
                'default' => [
                    [

                        'contact_icon' => esc_html__('fa fa-phone', 'noxiy-toolkit'),
                        'contact_name' => esc_html__('Phone', 'noxiy-toolkit'),
                        'contact_info' => esc_html__('0393488939', 'noxiy-toolkit'),
                        'contact_link' => esc_attr__('tel:0393488939', 'noxiy-toolkit'),
                    ],
                ],
                'title_field' => '{{{ contact_name }}}',
            ]
        );


        $this->end_controls_section();

    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $image_one = $settings['team_image'];
        ?>
        <div class="team__single-left">
            <div class="team__single-left-thumb dark__image">
                <?php
                if ($image_one['url']) {
                    if (!empty($image_one['alt'])) {
                        echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                    } else {
                        echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                    }
                }
                ?>

                <?php if (!empty($settings['social_media'])): ?>
                    <div class="team__single-left-thumb-social">
                        <ul>
                            <?php foreach ($settings['social_media'] as $item): ?>
                                <li><a href="<?php echo esc_url($item['link']); ?>"><i
                                            class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
            <div class="team__single-left-info">
                <span>
                    <?php echo esc_html($settings['sub_title']); ?>
                </span>
                <h3>
                    <?php echo esc_html($settings['title_one']); ?>
                </h3>
                <div class="team__single-left-info-contact">
                    <?php foreach ($settings['contact_list'] as $citem): ?>
                        <div class="team__single-left-info-contact-item">
                            <i class="<?php echo esc_attr($citem['contact_icon']['value']); ?>"></i>
                            <div class="team__single-left-info-contact-item-info">
                                <span>
                                    <?php echo esc_html($citem['contact_name']); ?>
                                </span>
                                <h5><a href="<?php echo esc_url($citem['contact_link']); ?>"><?php echo esc_html($citem['contact_info']); ?></a></h5>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

        </div>
        <?php
    }
}

Plugin::instance()->widgets_manager->register(new Team_Single_Noxiy);