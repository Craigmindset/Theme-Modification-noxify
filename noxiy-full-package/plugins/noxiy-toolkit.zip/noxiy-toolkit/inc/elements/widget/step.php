<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit;

class Step_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'step-noxiy';
    }

    public function get_title()
    {
        return esc_html__('Step - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-toolkit'];
    }

    public function get_keywords()
    {
        return ['noxiy', 'Toolkit', 'Process', 'step', 'work'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'step_1',
            [
                'label' => esc_html__('Work Step 01', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'icon_1',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'far fa-sun',
                    'library' => 'brands',
                ],
            ]
        );

        $this->add_control(
            'number_1',
            [
                'label' => esc_html__('Number', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('01', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title_1',
            [
                'label' => esc_html__('Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc_1',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'noxiy-toolkit'),
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'step_2',
            [
                'label' => esc_html__('Work Step 02', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'icon_2',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'far fa-sun',
                    'library' => 'brands',
                ],
            ]
        );

        $this->add_control(
            'number_2',
            [
                'label' => esc_html__('Number', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('02', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title_2',
            [
                'label' => esc_html__('Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc_2',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'noxiy-toolkit'),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'step_3',
            [
                'label' => esc_html__('Work Step 03', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'icon_3',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'far fa-sun',
                    'library' => 'brands',
                ],
            ]
        );

        $this->add_control(
            'number_3',
            [
                'label' => esc_html__('Number', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('03', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title_3',
            [
                'label' => esc_html__('Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc_3',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'noxiy-toolkit'),
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'step_4',
            [
                'label' => esc_html__('Work Step 04', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'icon_4',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'far fa-sun',
                    'library' => 'brands',
                ],
            ]
        );

        $this->add_control(
            'number_4',
            [
                'label' => esc_html__('Number', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('04', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title_4',
            [
                'label' => esc_html__('Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'desc_4',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Aenean a felis consequat, varius orci ut, varius metus.', 'noxiy-toolkit'),
            ]
        );


        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>
        <div class="work__area">
            <div class="container">
                <div class="row work-n">
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="work__area-item">
                            <div class="work__area-item-icon">
                                <i class="<?php echo esc_attr($settings['icon_1']['value']); ?>"></i>
                                <span>
                                    <?php echo esc_html($settings['number_1']); ?>
                                </span>
                            </div>

                            <div class="work__area-item-content">
                                <h5>
                                    <?php echo esc_html($settings['title_1']); ?>
                                </h5>
                                <p>
                                    <?php echo esc_html($settings['desc_1']); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="work__area-item">
                            <div class="work__area-item-icon">
                                <i class="<?php echo esc_attr($settings['icon_2']['value']); ?>"></i>
                                <span>
                                    <?php echo esc_html($settings['number_2']); ?>
                                </span>
                            </div>
                            <div class="work__area-item-content">
                                <h5>
                                    <?php echo esc_html($settings['title_2']); ?>
                                </h5>
                                <p>
                                    <?php echo esc_html($settings['desc_2']); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="work__area-item">
                            <div class="work__area-item-icon">
                                <i class="<?php echo esc_attr($settings['icon_3']['value']); ?>"></i>
                                <span>
                                    <?php echo esc_html($settings['number_3']); ?>
                                </span>
                            </div>
                            <div class="work__area-item-content">
                                <h5>
                                    <?php echo esc_html($settings['title_3']); ?>
                                </h5>
                                <p>
                                    <?php echo esc_html($settings['desc_3']); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="work__area-item">
                            <div class="work__area-item-icon">
                                <i class="<?php echo esc_attr($settings['icon_4']['value']); ?>"></i>
                                <span>
                                    <?php echo esc_html($settings['number_4']); ?>
                                </span>
                            </div>
                            <div class="work__area-item-content">
                                <h5>
                                    <?php echo esc_html($settings['title_4']); ?>
                                </h5>
                                <p>
                                    <?php echo esc_html($settings['desc_4']); ?>
                                </p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <?php
    }
}

Plugin::instance()->widgets_manager->register(new Step_Noxiy);