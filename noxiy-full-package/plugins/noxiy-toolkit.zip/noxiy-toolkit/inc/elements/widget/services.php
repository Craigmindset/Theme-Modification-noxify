<?php

namespace Elementor;

use Elementor\Utils;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

if (!defined('ABSPATH'))
    exit;

class Services_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'services_noxiy';
    }

    public function get_title()
    {
        return esc_html__('Services - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'Services', 'List', 'Item'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('Style & Options', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label' => esc_html__('Select a Style', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Style 01', 'noxiy-toolkit'),
                    'design-2' => esc_html__('Style 02', 'noxiy-toolkit'),
                    'design-3' => esc_html__('Style 03', 'noxiy-toolkit'),
                    'design-4' => esc_html__('Style 04', 'noxiy-toolkit'),
                ],
                'default' => 'design-1',
                'label_block' => true,
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Service Content', 'noxiy-toolkit'),
            ]
        );


        $content = new Repeater();

        $content->add_control(
            'icon',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fa fa-star',
                    'library' => 'brands',
                ],
            ]
        );

        $content->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $content->add_control(
            'description',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
            ]
        );

        $content->add_control(
            'item_url',
            [
                'label' => esc_html__('Item URL', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );



        $this->add_control(
            'content_items',
            [
                'label' => esc_html__('Content Items', 'noxiy-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $content->get_controls(),
                'default' => [
                    [
                        'title' => esc_html__('Wellness Program', 'noxiy-toolkit'),
                        'description' => esc_html__('Our Specialty Care program provides access to top medical specialists and centers', 'noxiy-toolkit'),
                        'item_url' => esc_attr__('http://google.com', 'noxiy-toolkit'),
                    ],

                    [
                        'title' => esc_html__('Specialty Care', 'noxiy-toolkit'),
                        'description' => esc_html__('Our Specialty Care program provides access to top medical specialists and centers', 'noxiy-toolkit'),
                        'item_url' => esc_attr__('http://google.com', 'noxiy-toolkit'),
                    ],
                ],

                'title_field' => '{{{ title }}}',
                'condition' => [
                    'select_design' => ['design-1'],
                ],
            ]
        );

        $this->add_control(
            'image_one',
            [
                'label' => esc_html__('Image One', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'select_design' => ['design-2','design-3'],
                ],
            ]
        );

        $this->add_control(
            'icon_one',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fa fa-star',
                    'library' => 'brands',
                ],
                'condition' => [
                    'select_design' => ['design-2', 'design-3', 'design-4'],
                ],
            ]
        );

        $this->add_control(
            'number',
            [
                'label' => esc_html__('Number', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('01', 'noxiy-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-3'],
                ],
            ]
        );

        $this->add_control(
            'title_one',
            [
                'label' => esc_html__('Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Services Quality', 'noxiy-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-2', 'design-3', 'design-4'],
                ],
            ]
        );

        $this->add_control(
            'content_one',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Proin pretium sem libero, nec aliquet augue lobortis', 'noxiy-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-2', 'design-3', 'design-4'],
                ],
            ]
        );

        $this->add_control(
            'btn_text',
            [
                'label' => esc_html__('Button', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Read More', 'noxiy-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-2', 'design-4'],
                ],
            ]
        );

        $this->add_control(
            'item_url',
            [
                'label' => esc_html__('Item URL', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_attr__('https://google.com', 'noxiy-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-2', 'design-3', 'design-4'],
                ],
            ]
        );

        $this->add_control(
            'theme_shape_img1',
            [
                'label' => esc_html__('Shape Image', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-4'],
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'services_item_style',
            [
                'label' => esc_html__('Item', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs(
            'item_tabs'
        );
        $this->start_controls_tab(
            'item_normal_tab',
            [
                'label' => esc_html__('Normal', 'noxiy-toolkit'),
            ]
        );
        $this->add_control(
            'item_background',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services__one-item' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .services__two-item' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .services__three-items' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .services__four-item' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'item_border_color',
            [
                'label' => esc_html__('Border Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services__one-item' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .services__four-item' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .services__three-items' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .services__two-item::after' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .services__three-item-icon::after' => 'border-color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'item_hover_tab',
            [
                'label' => esc_html__('Hover', 'noxiy-toolkit'),
            ]
        );
        $this->add_control(
            'item_hover_background',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services__one-item::before' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_responsive_control(
			'services_item_padding',
			[
				'type' => Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Padding', 'noxiy-toolkit' ),
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .services__four-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .services__three-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'separator' => 'before',
			]
		);

        $this->add_responsive_control(
            'services_item_radius',
            [
                'type' => Controls_Manager::DIMENSIONS,
                'label' => esc_html__('Border Radius', 'noxiy-toolkit'),
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .services__three-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'services_content_style',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs(
            'style_tabs'
        );
        $this->start_controls_tab(
            'style_normal_tab',
            [
                'label' => esc_html__('Normal', 'noxiy-toolkit'),
            ]
        );
		$this->add_control(
			'services_title',
			[
				'label' => esc_html__( 'Title', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
		);
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'services_typography',
				'selector' => '{{WRAPPER}} .services__four-item-left h3,
                {{WRAPPER}} .services__three-item-content h4,
                {{WRAPPER}} .services__two-item-content h4,
				{{WRAPPER}} .services__one-item-content h4',
			]
		);
        $this->add_control(
            'services_title_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services__four-item-left h3 a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services__one-item-content h4' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services__two-item-content h4' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services__three-item-content h4' => 'color: {{VALUE}}',
                ],
            ]
        );
		$this->add_control(
			'services_description',
			[
				'label' => esc_html__( 'Description', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
		);
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'services_description_typography',
				'selector' => '{{WRAPPER}} .services__four-item-left p,
                {{WRAPPER}} .services__three-item-content p,
                {{WRAPPER}} .services__two-item-content p,
				{{WRAPPER}} .services__one-item-content > p',
			]
		);
        $this->add_control(
            'services_description_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services__four-item-left p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services__three-item-content p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services__two-item-content p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services__one-item-content > p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'services_description_gap',
            [
                'label' => esc_html__('Gap', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .services__four-item-left p' => 'padding-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'services_description_border',
            [
                'label' => esc_html__('Border Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services__two-item-btn::before' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'style_hover_tab',
            [
                'label' => esc_html__('Hover', 'noxiy-toolkit'),
            ]
        );
        $this->add_control(
			'services_title_hover',
			[
				'label' => esc_html__( 'Title', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
		);
        $this->add_control(
            'services_title_color_hover',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services__four-item:hover .services__four-item-left h3 a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services__three-items .two .services__three-item-content h4 a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services__two-item:hover .services__two-item-content h4 a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'services_text_color_hover',
            [
                'label' => esc_html__('Hover Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services__four-item:hover .services__four-item-left h3 a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services__three-items .two .services__three-item-content h4 a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services__two-item:hover .services__two-item-content h4 a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
		$this->add_control(
			'services_description_hover',
			[
				'label' => esc_html__( 'Description', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
		);
        $this->add_control(
            'services_description_color_hover',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services__four-item:hover .services__four-item-left p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services__three-items .two .services__three-item-content p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services__two-item:hover .services__two-item-content p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'services_description_border_hover',
            [
                'label' => esc_html__('Border Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services__two-item:hover .services__two-item-btn::before' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();    
        $this->end_controls_section();

        $this->start_controls_section(
            'services_icon_style',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'services_icon_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services__four-item-left i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services__three-item-icon i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services__two-item-icon i::before' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services__one-item-content-icon i' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'services_hover_icon_color',
            [
                'label' => esc_html__('Hover Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services__one-item:hover .services__one-item-content-icon i' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'services_icon_background',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services__one-item-content-icon' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .services__three-item-icon i' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'services_icon_size',
            [
                'label' => esc_html__('Font Size', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .services__four-item-left i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .services__one-item-content-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .services__two-item-icon i::before' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .services__three-item-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'services_button_width',
            [
                'label' => esc_html__('Max Width', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .services__one-item-content-icon' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .services__three-item-icon i' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'services_button_style',
            [
                'label' => esc_html__('Button', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'services_btn_typography',
				'selector' => '{{WRAPPER}} .services__one-item-content > a,
				{{WRAPPER}} .services__two-item-btn a',
			]
		);

        $this->add_control(
            'services_button_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services__one-item-content > a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services__two-item-btn a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'services_button_hover_color',
            [
                'label' => esc_html__('Hover Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services__one-item:hover .services__one-item-content > a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services__two-item:hover .services__two-item-btn a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'services_button_background',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial__page-item-top-reviews h6' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'services_button_size',
            [
                'label' => esc_html__('Font Size', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .services__one-item-content-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'services_button_width1',
            [
                'label' => esc_html__('Max Width', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .-item-content-icon' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
			'services_button_padding',
			[
				'type' => Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Padding', 'noxiy-toolkit' ),
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .testimonial__page-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'separator' => 'before',
			]
		);
        
        $this->end_controls_section();

    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $image_one = $settings['image_one'];
        $theme_shape_img1 = $settings['theme_shape_img1'];
        ?>

        <?php if ('design-1' === $settings['select_design']): ?>
            <?php foreach ($settings['content_items'] as $item): ?>
                <div class="services__four-item">
                    <div class="services__four-item-left">
                        <i class="<?php echo esc_attr($item['icon']['value']); ?>"></i>
                        <h3><a href="<?php echo esc_url($item['item_url']); ?>"><?php echo esc_html($item['title']); ?></a></h3>
                        <p>
                            <?php echo esc_html($item['description']); ?>
                        </p>
                    </div>
                    <div class="services__four-item-right">
                        <a href="<?php echo esc_url($item['item_url']); ?>"><i class="flaticon-right-up"></i></a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <?php if ('design-2' === $settings['select_design']): ?>
            <div class="services__one-item m-0">
                <div class="services__one-item-image">
                    <?php
                    if ($image_one['url']) {
                        if (!empty($image_one['alt'])) {
                            echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                        } else {
                            echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                        }
                    }
                    ?>
                </div>
                <div class="services__one-item-content">
                    <div class="services__one-item-content-icon">
                        <i class="<?php echo esc_attr($settings['icon_one']['value']); ?>"></i>
                    </div>
                    <h4><a href="<?php echo esc_url($settings['item_url']); ?>"><?php echo esc_html($settings['title_one']); ?></a>
                    </h4>
                    <p>
                        <?php echo esc_html($settings['content_one']); ?>
                    </p>
                    <a href="<?php echo esc_url($settings['item_url']); ?>">
                        <p>
                            <?php echo esc_html($settings['btn_text']); ?>
                        </p><i class="fas fa-long-arrow-right"></i>
                    </a>
                </div>
            </div>
        <?php endif; ?>


        <?php if ('design-3' === $settings['select_design']): ?>
            <div class="services__three-items">
                <div class="two" data-background="<?php echo esc_url($image_one['url']);?>">
                    <span>
                        <?php echo esc_html($settings['number']); ?>
                    </span>
                    <div class="services__three-item-icon">
                        <i class="<?php echo esc_attr($settings['icon_one']['value']); ?>"></i>
                    </div>
                    <div class="services__three-item-content">
                        <h4><a href="<?php echo esc_url($settings['item_url']); ?>"><?php echo esc_html($settings['title_one']); ?></a></h4>
                        <p>
                            <?php echo esc_html($settings['content_one']); ?>
                        </p>
                    </div>
                </div>
                <div class="services__three-item">
                    <span>
                        <?php echo esc_html($settings['number']); ?>
                    </span>
                    <div class="services__three-item-icon">
                        <i class="<?php echo esc_attr($settings['icon_one']['value']); ?>"></i>
                    </div>
                    <div class="services__three-item-content">
                        <h4>
                            <?php echo esc_html($settings['title_one']); ?>
                        </h4>
                        <p>
                            <?php echo esc_html($settings['content_one']); ?>
                        </p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ('design-4' === $settings['select_design']): ?>
            <div class="services__two-item">
                <div class="services__two-item-icon">
                    <i class="<?php echo esc_attr($settings['icon_one']['value']); ?>"></i>
                </div>
                <div class="services__two-item-content">
                    <h4><a href="<?php echo esc_url($settings['item_url']); ?>"><?php echo esc_html($settings['title_one']); ?></a>
                    </h4>
                    <p>
                        <?php echo esc_html($settings['content_one']); ?>
                    </p>
                </div>
                <div class="services__two-item-btn">
                    <a href="<?php echo esc_url($settings['item_url']); ?>"><?php echo esc_html($settings['btn_text']); ?></a>
                </div>
            </div>

            <style>
            <?php if (!empty($theme_shape_img1['url'])): ?>
            .services__two-item::before {
                background-image: url('<?php echo esc_url($theme_shape_img1['url']);?>');
            }
            <?php endif; ?>
            </style>

        <?php endif; ?>

        <?php
    }
}

Plugin::instance()->widgets_manager->register(new Services_Noxiy);