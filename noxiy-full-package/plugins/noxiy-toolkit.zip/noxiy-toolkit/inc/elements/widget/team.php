<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;

if (!defined('ABSPATH'))
    exit;

class Teams_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'team-noxiy';
    }

    public function get_title()
    {
        return esc_html__('Team Member - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-toolkit'];
    }

    public function get_keywords()
    {
        return ['Noxiy', 'Toolkit', 'Team', 'Member'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('Team Style', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label' => esc_html__('Select Team Style', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Team Style 01', 'noxiy-toolkit'),
                    'design-2' => esc_html__('Team Style 02', 'noxiy-toolkit'),
                    'design-3' => esc_html__('Team Style 03', 'noxiy-toolkit'),
                    'design-4' => esc_html__('Team Style 04', 'noxiy-toolkit'),
                    'design-5' => esc_html__('Team Style 05', 'noxiy-toolkit'),
                    'design-6' => esc_html__('Team Style 06', 'noxiy-toolkit'),
                ],
                'default' => 'design-1',
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_head',
            [
                'label' => esc_html__('Team Content', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'team_image',
            [
                'label' => esc_html__('Team Image', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'title_one',
            [
                'label' => esc_html__('Name', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Amelia Clover', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'sub_title',
            [
                'label' => esc_html__('Position', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Senior Advisor', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'team_url',
            [
                'label' => esc_html__('Single URL', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_attr__('http://google.com', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'show_social',
            [
                'label' => esc_html__('Show Social', 'noxiy-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'noxiy-toolkit'),
                'label_off' => esc_html__('No', 'noxiy-toolkit'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $social_item = new Repeater();

        $social_item->add_control(
            'icon',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fab fa-facebook-f',
                    'library' => 'brands',
                ],
            ]
        );

        $social_item->add_control(
            'link',
            [
                'label' => esc_html__('URL', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'social_media',
            [
                'label' => esc_html__('Social Icons', 'noxiy-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $social_item->get_controls(),
                'default' => [
                    [

                        'icon' => esc_html__('fab fa-facebook-f', 'noxiy-toolkit'),
                        'link' => esc_attr__('https://facebook.com', 'noxiy-toolkit'),
                    ],
                ],

                'condition' => [
                    'show_social' => ['yes'],
                ],
                'title_field' => '{{{ icon }}}',
            ]
        );


        $this->end_controls_section();


        $this->start_controls_section(
            'team_style_section',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
		$this->add_control(
			'team_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'team_subtitle_typography',
				'selector' => '{{WRAPPER}} .team__six-item-content span,
				 {{WRAPPER}} .team__one-item-image-info-name span,
				 {{WRAPPER}} .team__two-item-content span,
				 {{WRAPPER}} .team__three-item-content span,
				 {{WRAPPER}} .team__four-item-content span, 
                 {{WRAPPER}} .team__five-item-content span',
			]
		);

        $this->add_control(
            'team_subtitle_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team__six-item-content span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__one-item-image-info-name span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__two-item-content span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__three-item-content span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__four-item-content span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__five-item-content span' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'team_subtitle_hover_color',
            [
                'label' => esc_html__('Hover Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team__one-item:hover .team__one-item-image-info-name span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__five-item:hover .team__five-item-content span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__four-item:hover .team__four-item-content span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__three-item:hover .team__three-item-content span' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-3','design-4','design-5','design-6'],
                ]
            ]
        );

		$this->add_control(
			'team_heading',
			[
				'label' => esc_html__( 'Heading', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
                'separator' => 'before',
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'team_heading_typography',
				'selector' => '{{WRAPPER}} .team__six-item-content h4,
				 {{WRAPPER}} .team__one-item-image-info-name h4,
				 {{WRAPPER}} .team__two-item-content h4,
				 {{WRAPPER}} .team__three-item-content h4,
				 {{WRAPPER}} .team__four-item-content h4,
				 {{WRAPPER}} .team__five-item-content h4',
                 
			]
		);

        $this->add_control(
            'team_heading_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team__six-item-content h4 a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__one-item-image-info-name h4 a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__two-item-content h4 a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__three-item-content h4' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__four-item-content h4' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__five-item-content h4' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'team_heading_hover_color',
            [
                'label' => esc_html__('Hover Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team__six-item-content h4 a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__one-item:hover .team__one-item-image-info-name h4 a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__two-item-content h4 a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__five-item:hover .team__five-item-content h4' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__four-item:hover .team__four-item-content h4' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__three-item:hover .team__three-item-content h4' => 'color: {{VALUE}}',
                ],
            ]
        );

		$this->add_control(
			'team_background',
			[
				'label' => esc_html__( 'Background', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'select_design' => ['design-4','design-5','design-6'],
                ]
			]
		);


        $this->add_control(
            'team_linear_color',
            [
                'label' => esc_html__('Linear Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team__one-item-image::after' => 'background: linear-gradient(180deg, rgba(249, 77, 29, 0) 0%,{{VALUE}} 85.11%)',
                ],
                'condition' => [
                    'select_design' => ['design-3'],
                ]
            ]
        );

        $this->add_control(
            'team_content_background',
            [
                'label' => esc_html__('Background Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team__two-item-content' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .team__five-item-content' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .team__four-item-content' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .team__three-item-content' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-4','design-5','design-6'],
                ]
            ]
        );

        $this->add_control(
            'team_content_hover_background',
            [
                'label' => esc_html__('Hover Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team__three-item:hover .team__three-item-content' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .team__four-item-content::before' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .team__five-item:hover .team__five-item-content' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-4','design-5','design-6'],
                ]
            ]
        );

        $this->add_responsive_control(
			'icon_border_radius',
			[
				'type' => Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Border Radius', 'noxiy-toolkit' ),
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .team__two-item-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .team__five-item-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .team__four-item-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .team__three-item-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'separator' => 'before',
                'condition' => [
                    'select_design' => ['design-2','design-4','design-5','design-6'],
                ]
			]
		);

        $this->add_responsive_control(
			'icon_style_padding',
			[
				'type' => Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Padding', 'noxiy-toolkit' ),
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .team__two-item-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .team__five-item-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .team__four-item-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .team__three-item-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .team__one-item-image-info' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'condition' => [
                    'select_design' => ['design-2','design-3','design-4','design-5','design-6'],
                ]
			]
		);

        $this->add_responsive_control(
			'icon_style_margin',
			[
				'type' => Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Margin', 'noxiy-toolkit' ),
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .team__two-item-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .team__five-item-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .team__four-item-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .team__three-item-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'condition' => [
                    'select_design' => ['design-2','design-4','design-5','design-6'],
                ]
			]
		);

        $this->end_controls_section();


        

        $this->start_controls_section(
            'team_icon_style',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );   

		$this->add_control(
			'team_social',
			[
				'label' => esc_html__( 'Social', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
		);

        $this->start_controls_tabs(
            'style_tabs'
        );

        $this->start_controls_tab(
            'style_normal_tab',
            [
                'label' => esc_html__('Normal', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'team_icon_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team__two-item-image-social ul li a i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__four-item-image-social ul li a i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__five-item-image-social ul li a i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__three-item-content ul li a i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__one-item-image-info-social ul li a i' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'team_icon_background',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team__two-item-image-social ul li a i' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .team__four-item-image-social ul li a i' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .team__five-item-image-social ul li a i' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .team__three-item-content ul li a i' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .team__one-item-image-info-social::before' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'style_hover_tab',
            [
                'label' => esc_html__('Hover', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'team_icon_hover_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team__two-item-image-social ul li a i:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__four-item-image-social ul li a i:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__five-item-image-social ul li a i:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__three-item-content ul li a i:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'team_icon_hover_background',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team__two-item-image-social ul li a i:hover' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .team__four-item-image-social ul li a i:hover' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .team__five-item-image-social ul li a i:hover' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .team__three-item-content ul li a i:hover' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_responsive_control(
            'social_icon_space',
            [
                'label' => esc_html__('Gap', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'default' => [
					'unit' => 'px',
					'size' => 8,
				],
                'selectors' => [
                    '{{WRAPPER}} .team__two-item-image-social ul li' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'social_icon_width',
            [
                'label' => esc_html__('Max Width', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
					'unit' => 'px',
					'size' => 45,
				],
                'selectors' => [
                    '{{WRAPPER}} .team__two-item-image-social ul li a i' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );        

        $this->add_responsive_control(
            'social_icon_size',
            [
                'label' => esc_html__('Icon Size', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'default' => [
					'unit' => 'px',
					'size' => 14,
				],
                'selectors' => [
                    '{{WRAPPER}} .team__two-item-image-social ul li a i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        

		$this->add_control(
			'team_share',
			[
				'label' => esc_html__( 'Share', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'select_design' => ['design-1','design-2','design-3'],
                ]
			]
		);

        $this->add_control(
            'team_share_icon_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team__one-item-image-info-icon span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team__two-item-image-icon span' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-1','design-2','design-3'],
                ]
            ]
        );

        $this->add_control(
            'team_share_icon_background',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team__one-item-image-info-icon span' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .team__two-item-image-icon span' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .team__one-item-image-info-icon::after' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'select_design' => ['design-1','design-2','design-3'],
                ]
            ]
        );

        $this->add_responsive_control(
            'share_icon_width',
            [
                'label' => esc_html__('Max Width', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
					'unit' => 'px',
					'size' => 45,
				],
                'selectors' => [
                    '{{WRAPPER}} .team__one-item-image-info-icon span' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .team__two-item-image-icon span' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'select_design' => ['design-1','design-2','design-3'],
                ]
            ]
        );        

        $this->add_responsive_control(
            'share_icon_size',
            [
                'label' => esc_html__('Icon Size', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'default' => [
					'unit' => 'px',
					'size' => 14,
				],
                'selectors' => [
                    '{{WRAPPER}} .team__one-item-image-info-icon span' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .team__two-item-image-icon span' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'select_design' => ['design-1','design-2','design-3'],
                ]
            ]
        );

   
        $this->end_controls_section();
        

        
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $team_image = $settings['team_image'];

    ?>
        <?php if ('design-1' === $settings['select_design']): ?>

            <div class="team__six-item">
				<div class="team__six-item-image">
                    <?php
                    if ($team_image['url']) {
                        if (!empty($team_image['alt'])) {
                            echo '<img src="' . esc_url($team_image['url']) . '" alt="' . esc_attr($team_image['alt']) . '" />';
                        } else {
                            echo '<img src="' . esc_url($team_image['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                        }
                    } ?>
					<div class="team__two-item-image-icon four">
                        <?php if ('yes' === $settings['show_social'] && !empty($settings['social_media'])): ?>
                            <div class="team__two-item-image-social">
                                <ul>
                                    <?php foreach ($settings['social_media'] as $item): ?>
                                        <li><a href="<?php echo esc_url($item['link']); ?>"><i
                                        class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
							<span><i class="fas fa-share-alt"></i></span>
                        <?php endif; ?>
                    </div>
				</div>
				<div class="team__six-item-content">
					<span><?php echo esc_html($settings['sub_title']); ?></span>
					<?php if (!empty($settings['team_url'])) { ?>
                        <h4><a href="<?php echo esc_url($settings['team_url']); ?>"><?php echo esc_html($settings['title_one']); ?></a></h4>
                    <?php } else { ?>
                        <h4><?php echo esc_html($settings['title_one']); ?></h4>
                    <?php } ?>						
				</div>
			</div>

        <?php endif; ?>

        <?php if ('design-2' === $settings['select_design']): ?>

			<div class="team__two-item">
				<div class="team__two-item-image">
                    <?php
                    if ($team_image['url']) {
                        if (!empty($team_image['alt'])) {
                            echo '<img src="' . esc_url($team_image['url']) . '" alt="' . esc_attr($team_image['alt']) . '" />';
                        } else {
                            echo '<img src="' . esc_url($team_image['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                        }
                    } ?>
					<div class="team__two-item-image-icon">
                        <?php if ('yes' === $settings['show_social'] && !empty($settings['social_media'])): ?>
                            <div class="team__two-item-image-social">
                                <ul>
                                    <?php foreach ($settings['social_media'] as $item): ?>
                                        <li><a href="<?php echo esc_url($item['link']); ?>"><i
                                        class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a></li>
                                    <?php endforeach; ?>
								</ul>
                            </div>
							<span><i class="fas fa-share-alt"></i></span>
                        <?php endif; ?>
                    </div>
				</div>
				<div class="team__two-item-content">
					<span><?php echo esc_html($settings['sub_title']); ?></span>
					<?php if (!empty($settings['team_url'])) { ?>
                        <h4><a href="<?php echo esc_url($settings['team_url']); ?>"><?php echo esc_html($settings['title_one']); ?></a></h4>
                    <?php } else { ?>
                        <h4><?php echo esc_html($settings['title_one']); ?></h4>
                    <?php } ?>	
				</div>
			</div>

        <?php endif; ?>

        <?php if ('design-3' === $settings['select_design']): ?>

            <div class="team__one-item">
				<div class="team__one-item-image">
                    <?php
                    if ($team_image['url']) {
                        if (!empty($team_image['alt'])) {
                            echo '<img src="' . esc_url($team_image['url']) . '" alt="' . esc_attr($team_image['alt']) . '" />';
                        } else {
                            echo '<img src="' . esc_url($team_image['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                        }
                    } ?>
                    <div class="team__one-item-image-info">
                        <div class="team__one-item-image-info-name">
                            <span><?php echo esc_html($settings['sub_title']); ?></span>
                            <?php if (!empty($settings['team_url'])) { ?>
                                <h4><a href="<?php echo esc_url($settings['team_url']); ?>"><?php echo esc_html($settings['title_one']); ?></a></h4>
                            <?php } else { ?>
                                <h4><?php echo esc_html($settings['title_one']); ?></h4>
                            <?php } ?>	
                        </div>
                        <div class="team__one-item-image-info-icon">
                            <?php if ('yes' === $settings['show_social'] && !empty($settings['social_media'])): ?>
                                <div class="team__one-item-image-info-social">
                                    <ul>
                                        <?php foreach ($settings['social_media'] as $item): ?>
                                            <li><a href="<?php echo esc_url($item['link']); ?>"><i
                                            class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                                <span><i class="fas fa-share-alt"></i></span>
                            <?php endif; ?>
                        </div> 
                    </div>
				</div>
			</div>            

        <?php endif; ?>

        <?php if ('design-4' === $settings['select_design']): ?>

            <div class="team__four-item">
				<div class="team__four-item-image">
                    <?php
                    if ($team_image['url']) {
                        if (!empty($team_image['alt'])) {
                            echo '<img src="' . esc_url($team_image['url']) . '" alt="' . esc_attr($team_image['alt']) . '" />';
                        } else {
                            echo '<img src="' . esc_url($team_image['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                        }
                    } ?>
                    <?php if ('yes' === $settings['show_social'] && !empty($settings['social_media'])): ?>
                        <div class="team__four-item-image-social">
                            <ul>
                                <?php foreach ($settings['social_media'] as $item): ?>
                                    <li><a href="<?php echo esc_url($item['link']); ?>"><i
                                    class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
				</div>
				<div class="team__four-item-content">
                    <span><?php echo esc_html($settings['sub_title']); ?></span>
                    <?php if (!empty($settings['team_url'])) { ?>
                        <h4><a href="<?php echo esc_url($settings['team_url']); ?>"><?php echo esc_html($settings['title_one']); ?></a></h4>
                    <?php } else { ?>
                        <h4><?php echo esc_html($settings['title_one']); ?></h4>
                    <?php } ?>	
				</div>
			</div>         

        <?php endif; ?>
        
        <?php if ('design-5' === $settings['select_design']): ?>

            <div class="team__five-item">
			    <div class="team__five-item-image">
                    <?php
                    if ($team_image['url']) {
                        if (!empty($team_image['alt'])) {
                            echo '<img src="' . esc_url($team_image['url']) . '" alt="' . esc_attr($team_image['alt']) . '" />';
                        } else {
                            echo '<img src="' . esc_url($team_image['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                        }
                    } ?>
                    <?php if ('yes' === $settings['show_social'] && !empty($settings['social_media'])): ?>
                        <div class="team__five-item-image-social">
                            <ul>
                                <?php foreach ($settings['social_media'] as $item): ?>
                                    <li><a href="<?php echo esc_url($item['link']); ?>"><i
                                    class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
			    </div>
			    <div class="team__five-item-content">
                    <span><?php echo esc_html($settings['sub_title']); ?></span>
                    <?php if (!empty($settings['team_url'])) { ?>
                        <h4><a href="<?php echo esc_url($settings['team_url']); ?>"><?php echo esc_html($settings['title_one']); ?></a></h4>
                    <?php } else { ?>
                        <h4><?php echo esc_html($settings['title_one']); ?></h4>
                    <?php } ?>	
			    </div>
		    </div>       

        <?php endif; ?>
        
        <?php if ('design-6' === $settings['select_design']): ?>

            <div class="team__three-item">
				<div class="team__three-item-image">
                    <?php
                    if ($team_image['url']) {
                        if (!empty($team_image['alt'])) {
                            echo '<img src="' . esc_url($team_image['url']) . '" alt="' . esc_attr($team_image['alt']) . '" />';
                        } else {
                            echo '<img src="' . esc_url($team_image['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                        }
                    } ?>
				</div>
				<div class="team__three-item-content">
                    <span><?php echo esc_html($settings['sub_title']); ?></span>
                    <?php if (!empty($settings['team_url'])) { ?>
                        <h4><a href="<?php echo esc_url($settings['team_url']); ?>"><?php echo esc_html($settings['title_one']); ?></a></h4>
                    <?php } else { ?>
                        <h4><?php echo esc_html($settings['title_one']); ?></h4>
                    <?php } ?>	
                    <?php if ('yes' === $settings['show_social'] && !empty($settings['social_media'])): ?>
					    <ul>
                            <?php foreach ($settings['social_media'] as $item): ?>
                                <li><a href="<?php echo esc_url($item['link']); ?>"><i
                                class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a></li>
                            <?php endforeach; ?>
					    </ul>
                    <?php endif; ?>
				</div>
            </div>

        <?php endif; ?>






    <?php
    }
}

Plugin::instance()->widgets_manager->register(new Teams_Noxiy);