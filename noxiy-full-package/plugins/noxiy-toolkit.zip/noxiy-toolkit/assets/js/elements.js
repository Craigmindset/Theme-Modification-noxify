(function ($) {
    "use strict";

    var BannerSlider = function () {
	///============= * Banner Slider  =============\\\
	let sliderActive1 = '.banner-slider';
	let sliderInit1 = new Swiper(sliderActive1, {
		loop: true,
		slidesPerView: 1,
		effect: 'fade',
		autoplay: {
			delay: 5500,
			reverseDirection: false,
			disableOnInteraction: false,
		},
		navigation: {
			nextEl: '.noxiy-button-next',
			prevEl: '.noxiy-button-prev',
		},		
		pagination: {
			el: ".banner-pagination",
			type: "fraction",
			clickable: true,
		},
	});
	function animated_swiper(selector, init) {
		let animated = function animated() {
			$(selector + ' [data-animation]').each(function() {
				let anim = $(this).data('animation');
				let delay = $(this).data('delay');
				let duration = $(this).data('duration');
				$(this).removeClass('anim' + anim).addClass(anim + ' animated').css({
					webkitAnimationDelay: delay,
					animationDelay: delay,
					webkitAnimationDuration: duration,
					animationDuration: duration
				}).one('animationend', function() {
					$(this).removeClass(anim + ' animated');
				});
			});
		};
		animated();
		init.on('slideChange', function() {
			$(sliderActive1 + ' [data-animation]').removeClass('animated');
		});
		init.on('slideChange', animated);
	}
	animated_swiper(sliderActive1, sliderInit1);
		  
    }

var Skill_Bar = function () { 
	if($('.skill__area-item-bar').length) {
		$('.skill__area-item-bar').appear(function() {
			var el = $(this);
			var percent = el.data('width');
			$(el).css('width', percent + '%');
		}, {
			accY: 0
		});
	};

}
var Portfolio_All = function () { 
   	///============= * Portfolio Active Hover  =============\\\
	   const projectsItems = document.querySelectorAll('.portfolio__four-item');
	   projectsItems.forEach(item => {
		   const heading = item.querySelector('.portfolio__four-item-inner-content-btn');
		   heading.addEventListener('mouseenter', () => {
			   projectsItems.forEach(item => {
				   item.classList.remove('active');
			   });
			   item.classList.add('active');
		   });
	   });

	   	///============= * Portfolio Three Active Hover  =============\\\
	$(document).on("click", ".portfolio__three-item", function () {
		removeActiveClasses();
		$(this).addClass("active");
	});	
	function removeActiveClasses() {
		$(".portfolio__three-item").removeClass("active");
	}	

	
	///============= * Portfolio One  =============\\\
	var swiper = new Swiper(".portfolio__one-slider", {
		loop: true,
		speed: 2000,
		spaceBetween: 30,
		slidesPerView: 4,
		autoplay: {
			delay: 4500,
			reverseDirection: false,
			disableOnInteraction: false,
		},
		breakpoints: {
			1: {
				slidesPerView: 1
			},
			750: {
				spaceBetween: 30,
				slidesPerView: 2
			},
			1115: {
				spaceBetween: 25,
				slidesPerView: 3
			},
			1500: {
				slidesPerView: 4
			},
		}
	});		
	
}
 
var Testimonial_All = function () { 

		///============= * Testimonial Slider  =============\\\
		var mySwiper = new Swiper(".testimonial__slider", {
			direction: 'vertical',
			spaceBetween: 30,
			slidesPerView: 2,
			speed: 2000,
			loop: true,
			pagination: {
				el: ".testimonial-pagination",
				clickable: true,
			},
			autoplay: {
				delay: 4500,
				reverseDirection: false,
				disableOnInteraction: false,
			},
		});	
		///============= * Testimonial Two  =============\\\
		var galleryTop = new Swiper('.gallery-top', {
			spaceBetween: 10,
			navigation: {
			  nextEl: '.swiper-button-next',
			  prevEl: '.swiper-button-prev',
			},
			loop: true,
			loopedSlides: 4
		});
		var galleryThumbs = new Swiper('.gallery-thumbs', {
			spaceBetween: 10,
			centeredSlides: true,
			slidesPerView: 'auto',
			slideToClickedSlide: true,
			loop: true,
			loopedSlides: 4,
			autoplay: {
				delay: 4500,
				reverseDirection: false,
				disableOnInteraction: false,
			},
		});
		galleryTop.controller.control = galleryThumbs;
		galleryThumbs.controller.control = galleryTop;

			///============= * Request Quote  =============\\\
		var swiper = new Swiper(".request__quote-slider", {
			loop: true,
			speed: 1500,
			spaceBetween: 40,
			slidesPerView: 1,
			autoplay: {
				delay: 3500,
				reverseDirection: false,
				disableOnInteraction: false,
			},
			pagination: {
				el: ".request-pagination",
				clickable: true,
			},
		});	
	
}

var WidgetDefault = function ($scope, $) {

	///=============  Video Popup  =============\\\
	$('.video-popup').magnificPopup({
		type: 'iframe'
	});
	///=============  Image Popup  =============\\\
	$('.img-popup').magnificPopup({
		type: 'image',
		gallery: {
			enabled: true
		}
	});

	$("[data-background]").each(function() {
		$(this).css("background-image", "url(" + $(this).attr("data-background") + ")")
	});
    }

    $(window).on('elementor/frontend/init', function () {

        elementorFrontend.hooks.addAction('frontend/element_ready/banner_noxiy.default', BannerSlider);
        elementorFrontend.hooks.addAction('frontend/element_ready/skill_bar_noxiy.default', Skill_Bar);
        elementorFrontend.hooks.addAction('frontend/element_ready/portfolio_noxiy.default', Portfolio_All);
        elementorFrontend.hooks.addAction('frontend/element_ready/testimonial_noxiy.default', Testimonial_All);
		elementorFrontend.hooks.addAction('frontend/element_ready/widget', WidgetDefault);
    });


})(jQuery);