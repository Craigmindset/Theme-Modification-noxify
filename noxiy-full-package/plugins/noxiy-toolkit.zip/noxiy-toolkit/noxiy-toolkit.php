<?php

/**
 * Plugin Name:       Noxiy Toolkit
 * Plugin URI:        http://themeforest.net/user/themeori
 * Description:       This is a Toolkit Plugin Require to Run Noxiy WordPress Theme
 * Version:           1.0.5
 * Requires at least: 6.0
 * Requires PHP:      7.2
 * Author:            ThemeOri
 * Author URI:        http://themeforest.net/user/themeori
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       noxiy-toolkit
 * Domain Path:       /languages
 */

if (!defined('ABSPATH'))
	exit; // Exit if accessed directly

define('NOXIFY_FILE', __FILE__);
define('NOXIFY_URL', plugin_dir_url(NOXIFY_FILE));
define('NOXIFY_ASSETS', trailingslashit(NOXIFY_URL . 'assets'));
/**
 * Load plugin textdomain.
 */

if (!function_exists('noxiy_toolkit_init')) {

	function noxiy_toolkit_init()
	{
		load_plugin_textdomain('noxiy-toolkit', false, plugin_basename(dirname(__FILE__)) . '/languages');
	}
}
add_action('plugins_loaded', 'noxiy_toolkit_init');

/**
 * Load enqueue scripts
 */

if (!function_exists('noxiy_toolkit_enqueue_scripts')) {
	function noxiy_toolkit_enqueue_scripts()
	{
		wp_enqueue_style('noxiy-toolkit-elements', plugins_url('assets/css/elements.css', __FILE__), '1.0.0');
		wp_enqueue_script('noxiy-toolkit-elements', plugins_url('assets/js/elements.js', __FILE__), array('jquery'), '1.0.0', true);
	}
	add_action('wp_enqueue_scripts', 'noxiy_toolkit_enqueue_scripts', 20);
}

/**
 * Load csf plugin
 */

include_once('lib/csf/classes/setup.class.php');

if (class_exists('CSF')) {
	include_once('inc/sidebar-widget/recent-post-widget.php');
	include_once('inc/sidebar-widget/cta-image.php');
	include_once('inc/sidebar-widget/menu-list.php');
	include_once('inc/sidebar-widget/download.php');
}

/**
 * Load Custom Post Type
 */

include_once('inc/custom-post-type.php');
include_once('inc/builder-hook.php');

/**
 * check if elementor plugin has installed and active
 */

if (!function_exists('noxiy_toolkit_addons')) {

	function noxiy_toolkit_addons()
	{
		require_once('inc/elements/noxiy-addons.php');
		require_once('inc/elements/functions.php');
	}
}
add_action('elementor/init', 'noxiy_toolkit_addons');