<?php
/**
 * Prohibit direct script loading.
 *
 * @package Convert_Plus.
 */

// Silence is Golden.
