<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly

add_action('init', 'noxiy_custom_post_types');
function noxiy_custom_post_types()
{
    register_post_type('portfolio', array(
        'labels' => array(
            'name' => esc_html__('Portfolios', 'noxiy-toolkit'),
            'singular_name' => esc_html__('Portfolio', 'noxiy-toolkit'),
        ),
        'show_in_rest' => true,
        'supports' => array('title', 'thumbnail', 'page-attributes', 'editor', 'excerpt'),
        'show_in_menu' => true,
        'menu_position' => 24,
        'menu_icon' => esc_attr__('dashicons-portfolio', 'noxiy-toolkit'),
        'public' => true,
        'rewrite' => array(
            'slug' => 'portfolio',
            'with_front' => true
        )
    ));

    register_post_type('service', array(
        'labels' => array(
            'name' => esc_html__('Services', 'noxiy-toolkit'),
            'singular_name' => esc_html__('Service', 'noxiy-toolkit'),
        ),
        'show_in_rest' => true,
        'supports' => array('title', 'thumbnail', 'page-attributes', 'editor', 'excerpt'),
        'show_in_menu' => true,
        'menu_position' => 22,
        'menu_icon' => esc_attr__('dashicons-index-card', 'noxiy-toolkit'),
        'public' => true,
        'rewrite' => array(
            'slug' => 'service',
            'with_front' => true
        )
    ));

    register_post_type('noxiy_builder', array(
        'labels' => array(
            'name' => esc_html__('Template Builders', 'noxiy-toolkit'),
            'singular_name' => esc_html__('Template Builder', 'noxiy-toolkit'),
        ),
        'show_in_rest' => true,
        'supports' => array('title','editor'),
        'show_in_menu' => false,
        'menu_icon' => esc_attr__('dashicons-index-card', 'noxiy-toolkit'),
        'public' => true,
        'rewrite' => array(
            'slug' => 'noxiy_builder',
            'with_front' => true
        )
    ));
}


add_action('init', 'noxiy_custom_taxonomies');
function noxiy_custom_taxonomies()
{
    $portfolio_labels = array(
        'name' => esc_html__('Portfolio Categories', 'noxiy-toolkit'),
        'singular_name' => esc_html__('Portfolio Category', 'noxiy-toolkit'),
    );
    register_taxonomy('portfolio_category', 'portfolio', array(
        'labels' => $portfolio_labels,
        'show_in_rest' => true,
        'hierarchical' => true,
        'rewrite' => array(
            'slug' => 'portfolio-category',
            'with_front' => true
        ),
    ));
    $services_labels = array(
        'name' => esc_html__('Service Categories', 'noxiy-toolkit'),
        'singular_name' => esc_html__('Service Category', 'noxiy-toolkit'),
    );
    register_taxonomy('service_category', 'service', array(
        'labels' => $services_labels,
        'show_in_rest' => true,
        'hierarchical' => true,
        'rewrite' => array(
            'slug' => 'service-category',
            'with_front' => true
        ),
    ));
}


