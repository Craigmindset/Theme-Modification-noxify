<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit;

class Features_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'features-noxiy';
    }

    public function get_title()
    {
        return esc_html__('Features - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-toolkit'];
    }

    public function get_keywords()
    {
        return ['Noxiy', 'Toolkit', 'Features', 'section'];
    }

    protected function register_controls()
    {
        $this->start_controls_section(
            'section_content1',
            [
                'label' => esc_html__('Image', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'image_three',
            [
                'label' => esc_html__('BG Shape', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'image_two',
            [
                'label' => esc_html__('Image Right', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );


        $this->end_controls_section();


        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'image_one',
            [
                'label' => esc_html__('Sub Title Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'sub_title',
            [
                'label' => esc_html__('Sub Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Core Features', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Global Customers', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'content',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Welcome to our website, where we take pride', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'step_1',
            [
                'label' => esc_html__('Feature 01', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'icon_1',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'far fa-sun',
                    'library' => 'brands',
                ],
            ]
        );


        $this->add_control(
            'title_1',
            [
                'label' => esc_html__('Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'step_2',
            [
                'label' => esc_html__('Feature 02', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'icon_2',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'far fa-sun',
                    'library' => 'brands',
                ],
            ]
        );


        $this->add_control(
            'title_2',
            [
                'label' => esc_html__('Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Start Company', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'subtitle_style_section',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'fe_bg_color',
            [
                'label' => esc_html__('Section BG', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .features__two' => 'background: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'section_space',
            [
                'type' => Controls_Manager::DIMENSIONS,
                'label' => esc_html__('Section Padding', 'noxiy-toolkit'),
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .features__two' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );



        $this->add_control(
            'sub_title_color',
            [
                'label' => esc_html__('Sub Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .subtitle-three.only-noxiy' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__('Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .features__two-left-title h2' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );


        $this->add_control(
            'content_color',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .features__two-left-title p' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'subtitle_style_section1',
            [
                'label' => esc_html__('Features', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .features__two-left-bottom-item-icon::after' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .features__two-left-bottom-item-icon i' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'icon_hover_color',
            [
                'label' => esc_html__('Icon Hover', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .features__two-left-bottom-item:hover i' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'fe_bg_color_bg',
            [
                'label' => esc_html__('Item BG', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .features__two-left-bottom-item' => 'background: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'fe_hover_color',
            [
                'label' => esc_html__('Item BG Hover', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .features__two-left-bottom-item::before' => 'background: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );


        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $shape_img1 = $settings['image_one'];
        $image_one = $settings['image_two'];

        ?>

        <!-- Features Area Start -->
        <div class="features__two" data-background="<?php echo esc_url($settings['image_three']['url']); ?>">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 col-lg-7 lg-mb-30">
                        <div class="features__two-left">
                            <div class="features__two-left-title">
                                <span class="subtitle-three only-noxiy">
                                    <?php echo esc_html($settings['sub_title']); ?>
                                </span>
                                <h2>
                                    <?php echo esc_html($settings['title']); ?>
                                </h2>
                                <p>
                                    <?php echo esc_html($settings['content']); ?>
                                </p>
                            </div>
                            <div class="features__two-left-bottom">
                                <div class="features__two-left-bottom-item">
                                    <div class="features__two-left-bottom-item-icon">
                                        <i class="<?php echo esc_attr($settings['icon_1']['value']); ?>"></i>
                                    </div>
                                    <h5>
                                        <?php echo esc_html($settings['title_1']); ?>
                                    </h5>
                                </div>
                                <div class="features__two-left-bottom-item">
                                    <div class="features__two-left-bottom-item-icon">
                                        <i class="<?php echo esc_attr($settings['icon_2']['value']); ?>"></i>
                                    </div>
                                    <h5>
                                        <?php echo esc_html($settings['title_2']); ?>
                                    </h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-5">
                        <div class="features__two-right dark__image">
                            <?php
                            if ($image_one['url']) {
                                if (!empty($image_one['alt'])) {
                                    echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                                } else {
                                    echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Features Area End -->

        <style>
            <?php if (!empty($shape_img1['url'])): ?>
                .only-noxiy::before {
                    background-image: url("<?php echo esc_url($shape_img1['url']); ?>");
                }

            <?php endif; ?>
        </style>

        <?php
    }
}

Plugin::instance()->widgets_manager->register(new Features_Noxiy);