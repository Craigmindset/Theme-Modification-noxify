<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if (!defined('ABSPATH'))
    exit;

class Subtitle_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'subtitle-noxiy';
    }

    public function get_title()
    {
        return esc_html__('Subtitle - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-toolkit'];
    }

    public function get_keywords()
    {
        return ['noxiy', 'Toolkit', 'Subtitle', 'header'];
    }


    protected function register_controls()
    {


        $this->start_controls_section(
            'section_image',
            [
                'label' => esc_html__('Images', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'image_one',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'subtile_section_content',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit')
            ]
        );

        $this->add_control(
            'content_one',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Insurance Agency', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'subtitle_style_section',
            [
                'label' => esc_html__('Style', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
			'caption_align',
			[
				'label' => esc_html__( 'Alignment', 'noxiy-toolkit' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'noxiy-toolkit' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'noxiy-toolkit' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'noxiy-toolkit' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .subtitle-noxiy' => 'justify-content: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .subtitle-noxiy span',
			]
		);

        $this->add_control(
            'color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .subtitle-noxiy span' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );
        

        $this->add_control(
            'hover_color',
            [
                'label' => esc_html__('Hover Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .subtitle-noxiy span:hover' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'icon_space',
            [
                'label' => esc_html__('Icon Space', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'default' => [
					'unit' => 'px',
					'size' => 10,
				],
                'selectors' => [
                    '{{WRAPPER}} .subtitle-noxiy' => 'gap: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'icon_width',
            [
                'label' => esc_html__('Icon Size', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'default' => [
					'unit' => 'px',
					'size' => 20,
				],
                'selectors' => [
                    '{{WRAPPER}} .subtitle-noxiy img' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );


        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $image_one = $settings['image_one'];

        ?>


        <div class="subtitle-noxiy">
            <?php
            if ($image_one['url']) {
                if (!empty($image_one['alt'])) {
                    echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                } else {
                    echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                }
            }
            ?>
            <span>
                <?php echo esc_html($settings['content_one']); ?>
            </span>
        </div>


        <?php
    }
}

Plugin::instance()->widgets_manager->register(new Subtitle_Noxiy);