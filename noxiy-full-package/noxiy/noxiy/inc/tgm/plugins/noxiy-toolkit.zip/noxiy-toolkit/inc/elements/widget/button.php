<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit;

class Button_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'button-noxiy';
    }

    public function get_title()
    {
        return esc_html__('Button - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-toolkit'];
    }

    public function get_keywords()
    {
        return ['Noxiy', 'Toolkit', 'Button', 'left', 'right'];
    }

    protected function register_controls()
    {


        $this->start_controls_section(
            'btn_section_content',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'content_one',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Read More', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'link',
            [
                'label' => esc_html__('Link', 'noxiy-toolkit'),
                'type' => Controls_Manager::URL,
                'placeholder' => esc_html__('https://example.com', 'noxiy-toolkit'),
                'options' => ['url', 'is_external', 'nofollow'],
                'default' => [
                    'url' => '#',
                ],
                'label_block' => true,
            ]
        );

        $this->add_responsive_control(
            'align',
            [
                'label' => esc_html__('Alignment', 'noxiy-toolkit'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'noxiy-toolkit'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'noxiy-toolkit'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'noxiy-toolkit'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .noxiy-button' => 'text-align: {{VALUE}};',
                ],
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'btn_style_section',
            [
                'label' => esc_html__('Style', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'selector' => '{{WRAPPER}} .noxiy__btn',
            ]
        );

        $this->start_controls_tabs(
            'style_tabs'
        );

        $this->start_controls_tab(
            'style_normal_tab',
            [
                'label' => esc_html__('Normal', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .noxiy__btn' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_background_color',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .noxiy__btn' => 'background: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'style_hover_tab',
            [
                'label' => esc_html__('Hover', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'btn_hover_text_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .noxiy__btn:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'btn_hover_background_color',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .noxiy__btn::after' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .noxiy__btn::before' => 'background: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_responsive_control(
            'button_border_radius',
            [
                'type' => Controls_Manager::DIMENSIONS,
                'label' => esc_html__('Border Radius', 'noxiy-toolkit'),
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .noxiy__btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'button_padding',
            [
                'type' => Controls_Manager::DIMENSIONS,
                'label' => esc_html__('Padding', 'noxiy-toolkit'),
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .noxiy__btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        if (!empty($settings['link']['url'])) {
            $this->add_link_attributes('link', $settings['link']);
        }
        ?>

        <div class="noxiy-button">
            <a <?php echo $this->get_render_attribute_string('link'); ?> class="noxiy__btn">
                <?php echo esc_html($settings['content_one']); ?>
            </a>

        </div>

        <?php
    }
}

Plugin::instance()->widgets_manager->register(new Button_Noxiy);