<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit;

class Image_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'image-noxiy';
    }

    public function get_title()
    {
        return esc_html__('Images - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-toolkit'];
    }

    public function get_keywords()
    {
        return ['Noxiy', 'Toolkit', 'Images', 'left', 'right'];
    }

    protected function register_controls()
    {



        $this->start_controls_section(
            'section_style',
            [
                'label' => esc_html__('Image Style', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label' => esc_html__('Select Image Style', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Style 01', 'noxiy-toolkit'),
                    'design-2' => esc_html__('Style 02', 'noxiy-toolkit'),
                    'design-3' => esc_html__('Style 03', 'noxiy-toolkit'),
                    'design-4' => esc_html__('Style 04', 'noxiy-toolkit'),
                    'design-5' => esc_html__('Style 05', 'noxiy-toolkit'),
                    'design-6' => esc_html__('Style 06', 'noxiy-toolkit'),
                    'design-7' => esc_html__('Style 07', 'noxiy-toolkit'),
                    'design-8' => esc_html__('Style 08', 'noxiy-toolkit'),
                    'design-9' => esc_html__('Style 09', 'noxiy-toolkit'),
                    'design-10' => esc_html__('Style 10', 'noxiy-toolkit'),
                    'design-11' => esc_html__('Style 11', 'noxiy-toolkit'),
                ],
                'default' => 'design-1',
                'label_block' => true,
            ]
        );


        $this->end_controls_section();


        $this->start_controls_section(
            'image_section_image',
            [
                'label' => esc_html__('Images', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'shape_one',
            [
                'label' => esc_html__('Shape One', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'select_design' => ['design-1', 'design-2', 'design-3', 'design-6', 'design-10'],
                ]
            ]
        );

        $this->add_control(
            'shape_two',
            [
                'label' => esc_html__('Shape Two', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'select_design' => ['design-2', 'design-10'],
                ]
            ]
        );

        $this->add_control(
            'image_one',
            [
                'label' => esc_html__('Image One', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'image_two',
            [
                'label' => esc_html__('Image Two', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'select_design' => ['design-1', 'design-2', 'design-3', 'design-5', 'design-7', 'design-8', 'design-10'],
                ]
            ]
        );

        $this->add_control(
            'image_three',
            [
                'label' => esc_html__('Image Three', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'select_design' => ['design-1'],
                ]
            ]
        );



        $this->end_controls_section();

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'condition' => [
                    'select_design' => ['design-1', 'design-4', 'design-6', 'design-7', 'design-9','design-11'],
                ]
            ]
        );

        $this->add_control(
            'icon',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fa fa-star',
                    'library' => 'brands',
                ],
            ]
        );

        $this->add_control(
            'content_one',
            [
                'label' => esc_html__('Content One', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Years Experience Our Company', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'content_two',
            [
                'label' => esc_html__('Content Two', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Experience that delivers every time.', 'noxiy-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-6'],
                ]
            ]
        );

        $this->add_control(
            'content_number',
            [
                'label' => esc_html__('Content Number', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('31', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'content_prefix',
            [
                'label' => esc_html__('Counter Prefix', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('+', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'image_style_section',
            [
                'label' => esc_html__('Style', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_control(
			'image_title',
			[
				'label' => esc_html__( 'Title', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
		);

        $this->add_control(
            'image_content_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .about__five-left-image-experience h1' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .about__five-left-image-experience h6' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .about__one-left-image-experience h2' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .about__one-left-image-experience h6' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .about__three-left-image-experience h1' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .about__three-left-image-experience h5' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .faq__one-left-image-question h6' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .benefits__area-left-image-from h2' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .benefits__area-left-image-from h6' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'image_content_background',
            [
                'label' => esc_html__('Background Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .about__five-left-image-experience' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .about__one-left-image-experience' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .about__three-left-image-experience' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .faq__one-left-image-question' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .benefits__area-left-image-from' => 'background: {{VALUE}}',
                ],
            ]
        );

		$this->add_control(
			'image_title_icon',
			[
				'label' => esc_html__( 'Icon', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
                'separator' => 'before',
			]
		);

        $this->add_control(
            'image_icon_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .faq__one-left-image-question-icon i' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'image_icon_background',
            [
                'label' => esc_html__('Background Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .faq__one-left-image-question-icon i' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .faq__one-left-image-question-icon i::after' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
			'button_border_radius',
			[
				'type' => Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Border Radius', 'noxiy-toolkit' ),
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .about__five-left-image-experience' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .about__one-left-image-experience' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .about__three-left-image-experience' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .faq__one-left-image-question' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .benefits__area-left-image-from' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'separator' => 'before',
			]
		);

        $this->add_responsive_control(
			'button_padding',
			[
				'type' => Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Padding', 'noxiy-toolkit' ),
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .about__five-left-image-experience' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .about__one-left-image-experience' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .about__three-left-image-experience' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .faq__one-left-image-question' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .benefits__area-left-image-from' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'separator' => 'before',
			]
		);



        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $shape_one = $settings['shape_one'];
        $shape_two = $settings['shape_two'];
        $image_one = $settings['image_one'];
        $image_two = $settings['image_two'];
        $image_three = $settings['image_three'];
        ?>


        <?php if ('design-1' === $settings['select_design']): ?>

            <div class="about__five-left">
                <?php
                if ($shape_one['url']) {
                    if (!empty($shape_one['alt'])) {
                        echo '<img class="about__five-left-shape" src="' . esc_url($shape_one['url']) . '" alt="' . esc_attr($shape_one['alt']) . '" />';
                    } else {
                        echo '<img class="about__five-left-shape" src="' . esc_url($shape_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                    }
                }
                ?>
                <div class="about__five-left-image">
                    <div class="about__five-left-image-left image-overlay">
                        <?php
                        if ($image_one['url']) {
                            if (!empty($image_one['alt'])) {
                                echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                            } else {
                                echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                            }
                        }
                        ?>
                    </div>
                    <div class="about__five-left-image-right">
                        <div class="image-overlay">
                            <?php
                            if ($image_two['url']) {
                                if (!empty($image_two['alt'])) {
                                    echo '<img src="' . esc_url($image_two['url']) . '" alt="' . esc_attr($image_two['alt']) . '" />';
                                } else {
                                    echo '<img src="' . esc_url($image_two['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                                }
                            }
                            ?>
                        </div>
                        <div class="image-overlay">
                            <?php
                            if ($image_three['url']) {
                                if (!empty($image_three['alt'])) {
                                    echo '<img src="' . esc_url($image_three['url']) . '" alt="' . esc_attr($image_three['alt']) . '" />';
                                } else {
                                    echo '<img src="' . esc_url($image_three['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                                }
                            }
                            ?>
                        </div>
                    </div>
                    <div class="about__five-left-image-experience">
                        <h1><span class="counter">
                                <?php echo esc_html($settings['content_number']); ?>
                            </span><?php echo esc_html($settings['content_prefix']); ?>
                        </h1>
                        <h6>
                            <?php echo esc_html($settings['content_one']); ?>
                        </h6>
                    </div>
                </div>
            </div>

        <?php endif; ?>


        <?php if ('design-2' === $settings['select_design']): ?>

            <div class="who__area-right">
                <div class="who__area-right-image t-right">
                    <?php
                    if ($shape_one['url']) {
                        if (!empty($shape_one['alt'])) {
                            echo '<img class="who__area-right-image-shape" src="' . esc_url($shape_one['url']) . '" alt="' . esc_attr($shape_one['alt']) . '" />';
                        } else {
                            echo '<img class="who__area-right-image-shape" src="' . esc_url($shape_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                        }
                    }
                    ?>

                    <?php
                    if ($shape_two['url']) {
                        if (!empty($shape_two['alt'])) {
                            echo '<img class="who__area-right-image-shape-one left-right-animate" src="' . esc_url($shape_two['url']) . '" alt="' . esc_attr($shape_two['alt']) . '" />';
                        } else {
                            echo '<img class="who__area-right-image-shape-one left-right-animate" src="' . esc_url($shape_two['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                        }
                    }
                    ?>

                    <div class="image-overlay dark__image">
                        <?php
                        if ($image_one['url']) {
                            if (!empty($image_one['alt'])) {
                                echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                            } else {
                                echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                            }
                        }
                        ?>
                    </div>
                    <div class="image-overlay dark__image">
                        <?php
                        if ($image_two['url']) {
                            if (!empty($image_two['alt'])) {
                                echo '<img src="' . esc_url($image_two['url']) . '" alt="' . esc_attr($image_two['alt']) . '" />';
                            } else {
                                echo '<img src="' . esc_url($image_two['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>

        <?php endif; ?>


        <?php if ('design-3' === $settings['select_design']): ?>

            <div class="benefits__two-left">
				<div class="benefits__two-left-image">
                    <?php
                    if ($shape_one['url']) {
                        if (!empty($shape_one['alt'])) {
                            echo '<img class="benefits__two-left-image-shape" src="' . esc_url($shape_one['url']) . '" alt="' . esc_attr($shape_one['alt']) . '" />';
                        } else {
                            echo '<img class="benefits__two-left-image-shape" src="' . esc_url($shape_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                        }
                    }
                    ?>
					<div class="image-overlay dark__image">
                        <?php
                        if ($image_one['url']) {
                            if (!empty($image_one['alt'])) {
                                echo '<img class="benefits__two-left-image-one" src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                            } else {
                                echo '<img class="benefits__two-left-image-one" src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                            }
                        }
                        ?>
					</div>
					<div class="benefits__two-left-image-two image-overlay dark__image">
                        <?php
                        if ($image_two['url']) {
                            if (!empty($image_two['alt'])) {
                                echo '<img src="' . esc_url($image_two['url']) . '" alt="' . esc_attr($image_two['alt']) . '" />';
                            } else {
                                echo '<img src="' . esc_url($image_two['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                            }
                        }
                        ?>						
					</div>
				</div>
			</div>

        <?php endif; ?>


        <?php if ('design-4' === $settings['select_design']): ?>

            <div class="about__one-left">
				<div class="about__one-left-image">
					<div class="image-overlay dark__image">
                        <?php
                        if ($image_one['url']) {
                            if (!empty($image_one['alt'])) {
                                echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                            } else {
                                echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                            }
                        }
                        ?>
					</div>
					<div class="about__one-left-image-experience">
                        <h2><span class="counter">
                                <?php echo esc_html($settings['content_number']); ?>
                            </span>
                            <?php echo esc_html($settings['content_prefix']); ?>
                        </h2>
                        <h6>
                            <?php echo esc_html($settings['content_one']); ?>
                        </h6>
					</div>
				</div>
			</div>

        <?php endif; ?>


        <?php if ('design-5' === $settings['select_design']): ?>

            <div class="offer__area-left">
				<div class="image-overlay dark__image">
                    <?php
                    if ($image_one['url']) {
                        if (!empty($image_one['alt'])) {
                            echo '<img class="offer__area-left-one" src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                        } else {
                            echo '<img class="offer__area-left-one" src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                        }
                    }
                    ?>
				</div>						
				<div class="image-overlay two dark__image">
                    <?php
                    if ($image_two['url']) {
                        if (!empty($image_two['alt'])) {
                            echo '<img src="' . esc_url($image_two['url']) . '" alt="' . esc_attr($image_two['alt']) . '" />';
                        } else {
                            echo '<img src="' . esc_url($image_two['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                        }
                    }
                    ?>
				</div>
			</div>

        <?php endif; ?>


        <?php if ('design-6' === $settings['select_design']): ?>

            <div class="about__three-left">
                <?php
                if ($shape_one['url']) {
                    if (!empty($shape_one['alt'])) {
                        echo '<img class="about__three-left-shape" src="' . esc_url($shape_one['url']) . '" alt="' . esc_attr($shape_one['alt']) . '" />';
                    } else {
                        echo '<img class="about__three-left-shape" src="' . esc_url($shape_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                    }
                }
                ?>
				<div class="about__three-left-image">
                    <div class="image-overlay dark__image">
                        <?php
                        if ($image_one['url']) {
                            if (!empty($image_one['alt'])) {
                                echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                            } else {
                                echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                            }
                        }
                        ?>
                    </div>
					<div class="about__three-left-image-experience" data-background="assets/img/shape/experience.png">
                        <h1><span class="counter">
                                <?php echo esc_html($settings['content_number']); ?>
                            </span>
                            <?php echo esc_html($settings['content_prefix']); ?>
                        </h1>
                        <h5>
                            <?php echo esc_html($settings['content_one']); ?>
                        </h5>
                        <p>
                            <?php echo esc_html($settings['content_two']); ?>
                        </p>
					</div>
				</div>
			</div>

        <?php endif; ?>        


        <?php if ('design-7' === $settings['select_design']): ?>

            <div class="faq__one-left">
                <div class="faq__one-left-image">
                    <div class="image-overlay">
                        <?php
                        if ($image_one['url']) {
                            if (!empty($image_one['alt'])) {
                                echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                            } else {
                                echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                            }
                        }
                        ?>
                    </div>
                    <div class="image-overlay faq__one-left-image-one">
                        <?php
                        if ($image_two['url']) {
                            if (!empty($image_two['alt'])) {
                                echo '<img src="' . esc_url($image_two['url']) . '" alt="' . esc_attr($image_two['alt']) . '" />';
                            } else {
                                echo '<img src="' . esc_url($image_two['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                            }
                        }
                        ?>
                    </div>
                    <div class="faq__one-left-image-question left-right-animate">
                        <div class="faq__one-left-image-question-icon">
                            <i class="flaticon-question-mark-1"></i>
                        </div>
                        <h6>
                            <?php echo esc_html($settings['content_one']); ?>
                        </h6>
                    </div>
                </div>
            </div>

        <?php endif; ?>        


        <?php if ('design-8' === $settings['select_design']): ?>

            <div class="about__two-left">
				<div class="about__two-left-image">
					<div class="image-overlay dark__image">
                    <?php
                    if ($image_one['url']) {
                        if (!empty($image_one['alt'])) {
                            echo '<img class="offer__area-left-one" src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                        } else {
                            echo '<img class="offer__area-left-one" src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                        }
                    }
                    ?>
					</div>
					<div class="about__two-left-image-two image-overlay dark__image">
                    <?php
                    if ($image_two['url']) {
                        if (!empty($image_two['alt'])) {
                            echo '<img src="' . esc_url($image_two['url']) . '" alt="' . esc_attr($image_two['alt']) . '" />';
                        } else {
                            echo '<img src="' . esc_url($image_two['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                        }
                    }
                    ?>
					</div>
				</div>
			</div>

        <?php endif; ?>


        <?php if ('design-9' === $settings['select_design']): ?>

			<div class="benefits__area-left">
				<div class="benefits__area-left-image">
					<div class="image-overlay dark__image">
                        <?php
                        if ($image_one['url']) {
                            if (!empty($image_one['alt'])) {
                                echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                            } else {
                                echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                            }
                        }
                        ?>
					</div>
					<div class="benefits__area-left-image-from">
                        <h6>
                            <?php echo esc_html($settings['content_one']); ?>
                        </h6>
                        <h2>
                            <?php echo esc_html($settings['content_two']); ?>
                        </h2>
					</div>
				</div>
			</div>

        <?php endif; ?>

        
        <?php if ('design-10' === $settings['select_design']): ?>

            <div class="about__four-left">
				<div class="about__four-left-image">
                    <?php
                    if ($shape_one['url']) {
                        if (!empty($shape_one['alt'])) {
                            echo '<img class="about__four-left-image-shape" src="' . esc_url($shape_one['url']) . '" alt="' . esc_attr($shape_one['alt']) . '" />';
                        } else {
                            echo '<img class="about__four-left-image-shape" src="' . esc_url($shape_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                        }
                    }
                    ?>
                    <?php
                    if ($shape_two['url']) {
                        if (!empty($shape_two['alt'])) {
                            echo '<img class="about__four-left-image-shape-one left-right-animate" src="' . esc_url($shape_two['url']) . '" alt="' . esc_attr($shape_two['alt']) . '" />';
                        } else {
                            echo '<img class="about__four-left-image-shape-one left-right-animate" src="' . esc_url($shape_two['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                        }
                    }
                    ?>
					<div class="image-overlay dark__image">
                        <?php
                        if ($image_one['url']) {
                            if (!empty($image_one['alt'])) {
                                echo '<img class="about__four-left-image-one" src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                            } else {
                                echo '<img class="about__four-left-image-one" src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                            }
                        }
                        ?>
					</div>
					<div class="about__four-left-image-two image-overlay dark__image">
                        <?php
                        if ($image_two['url']) {
                            if (!empty($image_two['alt'])) {
                                echo '<img src="' . esc_url($image_two['url']) . '" alt="' . esc_attr($image_two['alt']) . '" />';
                            } else {
                                echo '<img src="' . esc_url($image_two['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                            }
                        }
                        ?>
					</div>
				</div>
			</div>

        <?php endif; ?> 
        
        
        <?php if ('design-11' === $settings['select_design']): ?>

            <div class="banner__four-content-button-customer">
                <div>                        
                    <?php
                    if ($image_one['url']) {
                        if (!empty($image_one['alt'])) {
                            echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                        } else {
                            echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                        }
                    }
                    ?>
                </div>
                <div>
                    <h6><i class="<?php echo esc_attr($settings['icon']['value']); ?>"></i> <span class="counter">
                            <?php echo esc_html($settings['content_number']); ?>
                        </span>
                        <?php echo esc_html($settings['content_prefix']); ?>
                    </h6>
                    <h5>
                        <?php echo esc_html($settings['content_one']); ?>
                    </h5>
                </div>
            </div>

        <?php endif; ?>  
        


        <?php
    }
}

Plugin::instance()->widgets_manager->register(new Image_Noxiy);