<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;

if (!defined('ABSPATH'))
    exit;

class Testimonial_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'testimonial_noxiy';
    }

    public function get_title()
    {
        return esc_html__('Testimonial - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-toolkit'];
    }

    public function get_keywords()
    {
        return ['Noxiy', 'Toolkit', 'Client', 'Testimonial', 'Review'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('Testimonial Style', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label' => esc_html__('Select a Style', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Design 01', 'noxiy-toolkit'),
                    'design-2' => esc_html__('Design 02', 'noxiy-toolkit'),
                    'design-3' => esc_html__('Design 03', 'noxiy-toolkit'),
                    'design-4' => esc_html__('Design 04', 'noxiy-toolkit'),
                ],
                'default' => 'design-1',
                'label_block' => true,
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Testimonial Content', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'icon_one',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fa fa-star',
                    'library' => 'brands',
                ],
                'condition' => [
                    'select_design' => ['design-1'],
                ],
            ]
        );

        $this->add_control(
            'title_one',
            [
                'label' => esc_html__('Review Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Services Quality', 'noxiy-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-1'],
                ],
            ]
        );

        $this->add_control(
            'content_one',
            [
                'label' => esc_html__('Review Content', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Proin pretium sem libero, nec aliquet augue lobortis', 'noxiy-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-1'],
                ],
            ]
        );

        $this->add_control(
            'user_image',
            [
                'label' => esc_html__('Author Image', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-1'],
                ],

            ]
        );

        $this->add_control(
            'user_title',
            [
                'label' => esc_html__('Author Name', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__('James Millard', 'noxiy-toolkit'),
                'condition' => [
                    'select_design' => ['design-1'],
                ],
            ]
        );


        $this->add_control(
            'user_subtitle',
            [
                'label' => esc_html__('Author Position', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__('Web Developer', 'noxiy-toolkit'),
                'condition' => [
                    'select_design' => ['design-1'],
                ],
            ]
        );


        $testimonial_item = new Repeater();

        $testimonial_item->add_control(
            'author_image',
            [
                'label' => esc_html__('Author Image', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        $testimonial_item->add_control(
            'author_title',
            [
                'label' => esc_html__('Author Name', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );


        $testimonial_item->add_control(
            'authors_subtitle',
            [
                'label' => esc_html__('Author Position', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $testimonial_item->add_control(
            'authors_description',
            [
                'label' => esc_html__('Write Content', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
            ]
        );

        $testimonial_item->add_control(
            'service_type',
            [
                'label' => esc_html__('Service Type', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'testimonial_items',
            [
                'label' => esc_html__('Testimonial Slides', 'noxiy-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $testimonial_item->get_controls(),
                'default' => [
                    [
                        'author_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'authors_subtitle' => esc_html__('Web Designer', 'noxiy-toolkit'),
                        'author_title' => esc_html__('Sara Albert', 'noxiy-toolkit'),
                        'service_type' => esc_html__('Item Support', 'noxiy-toolkit'),
                        'authors_description' => esc_html__('Proin pretium sem libero, nec aliquet augue lobortis in. Phasellus nibh quam, molestie id est sit amet.', 'noxiy-toolkit'),
                    ],
                    [
                        'author_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'authors_subtitle' => esc_html__('Ui/Ux Designer', 'noxiy-toolkit'),
                        'author_title' => esc_html__('James Millard', 'noxiy-toolkit'),
                        'service_type' => esc_html__('Code Quality', 'noxiy-toolkit'),
                        'authors_description' => esc_html__('Proin pretium sem libero, nec aliquet augue lobortis in. Phasellus nibh quam, molestie id est sit amet.', 'noxiy-toolkit'),
                    ],
                    [
                        'author_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'authors_subtitle' => esc_html__('Developer', 'noxiy-toolkit'),
                        'author_title' => esc_html__('Richerd William', 'noxiy-toolkit'),
                        'service_type' => esc_html__('Design Quality', 'noxiy-toolkit'),
                        'authors_description' => esc_html__('Proin pretium sem libero, nec aliquet augue lobortis in. Phasellus nibh quam, molestie id est sit amet.', 'noxiy-toolkit'),
                    ],
                ],

                'title_field' => '{{{ author_title }}}',
                'condition' => [
                    'select_design' => ['design-2', 'design-3', 'design-4'],
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'testimonial_style_section',
            [
                'label' => esc_html__('Review Content', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_control(
			'author_review_title',
			[
				'label' => esc_html__( 'Title', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'author_review_typography',
				'selector' => '{{WRAPPER}} .testimonial__page-item-top-reviews h6,
				{{WRAPPER}} .testimonial__one-item-review h5',
			]
		);

        $this->add_control(
            'review_heading_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial__page-item-top-reviews h6' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial__one-item-review h5' => 'color: {{VALUE}}',
                ],
            ]
        );

		$this->add_control(
			'author_review_description',
			[
				'label' => esc_html__( 'Description', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'review_description_typography',
				'selector' => '{{WRAPPER}} .testimonial__page-item p,
				{{WRAPPER}} .testimonial__two-item-inner-client p,
				{{WRAPPER}} .request__quote-page-right-item h5,
				{{WRAPPER}} .testimonial__one-item p',
			]
		);

        $this->add_control(
            'review_description_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial__page-item p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .request__quote-page-right-item h5' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial__one-item p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial__two-item-inner-client p' => 'color: {{VALUE}}',
                ],
            ]
        );

		$this->add_control(
			'author_review_icon',
			[
				'label' => esc_html__( 'Icon', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
		);

        $this->add_control(
            'review_icon_color',
            [
                'label' => esc_html__('Icon Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial__page-item-top > i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial__one-item-bottom i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .request__quote-page-right-item-icon i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial__one-pagination .swiper-slide-active img' => 'border-color: {{VALUE}} !important',
                ],
            ]
        );

        $this->add_responsive_control(
            'review_icon_size',
            [
                'label' => esc_html__('Icon Size', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial__page-item-top > i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial__one-item-bottom i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .request__quote-page-right-item-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'review_content_gap',
            [
                'label' => esc_html__('Gap', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial__page-item-top' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'review_rating_color',
            [
                'label' => esc_html__('Rating Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial__page-item-top-reviews ul li i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial__one-item-review-rating i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial__two-item-inner-reviews i' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'review_style_padding',
			[
				'type' => Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Padding', 'noxiy-toolkit' ),
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .testimonial__page-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .testimonial__one-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'separator' => 'before',
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
            'author_style_section',
            [
                'label' => esc_html__('Author Content', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_control(
			'author_review_content',
			[
				'label' => esc_html__( 'Heading', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'author_heading_typography',
				'selector' => '{{WRAPPER}} .testimonial__page-item-bottom-name h5,
				{{WRAPPER}} .testimonial__two-item-inner-client h4,
				{{WRAPPER}} .request__quote-page-right-item-bottom-name h5,
				{{WRAPPER}} .testimonial__one-item-bottom-name h4',
			]
		);

        $this->add_control(
            'author_title_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial__page-item-bottom-name h5' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial__one-item-bottom-name h4' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .request__quote-page-right-item-bottom-name h5' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial__two-item-inner-client h4' => 'color: {{VALUE}}',
                ],
            ]
        );

		$this->add_control(
			'author_review_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'author_subtitle_typography',
				'selector' => '{{WRAPPER}} .testimonial__page-item-bottom-name span,
				{{WRAPPER}} .testimonial__two-item-bottom span,
				{{WRAPPER}} .request__quote-page-right-item-bottom-name span,
				{{WRAPPER}} .testimonial__one-item-bottom-name span',
			]
		);

        $this->add_control(
            'author_subtitle_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial__page-item-bottom-name span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .request__quote-page-right-item-bottom-name span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial__one-item-bottom-name span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial__two-item-bottom span' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'author_border_color',
            [
                'label' => esc_html__('Border Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial__page-item-bottom' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial__one-item' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial__one-item::after' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial__page-item-bottom::before' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial__two-item-inner-avatar img' => 'border-color: {{VALUE}} !important',
                    '{{WRAPPER}} .testimonial__two-item-inner-avatar .quote i::before' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'author_arrow_color',
            [
                'label' => esc_html__('Arrow Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial__page-item-bottom::before' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .testimonial__one-item::after' => 'background: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
			'author_style_padding',
			[
				'type' => Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Padding', 'noxiy-toolkit' ),
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .testimonial__page-item-bottom' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .testimonial__two-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'separator' => 'before',
			]
		);

        $this->end_controls_section();

    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $user_img1 = $settings['user_image'];


        ?>
        <?php if ('design-1' === $settings['select_design']): ?>

            <div class="testimonial__page-item">
                <div class="testimonial__page-item-top">
                    <i class="<?php echo esc_attr($settings['icon_one']['value']); ?>"></i>
                    <div class="testimonial__page-item-top-reviews">
                        <h6>
                            <?php echo esc_html($settings['title_one']); ?>
                        </h6>
                        <ul>
                            <li><i class="fas fa-star"></i></li>
                            <li><i class="fas fa-star"></i></li>
                            <li><i class="fas fa-star"></i></li>
                            <li><i class="fas fa-star"></i></li>
                            <li><i class="fas fa-star"></i></li>
                        </ul>
                    </div>
                </div>
                <p>
                    <?php echo esc_html($settings['content_one']); ?>
                </p>
                <div class="testimonial__page-item-bottom">
                    <?php
                    if ($user_img1['url']) {
                        if (!empty($user_img1['alt'])) {
                            echo '<img src="' . esc_url($user_img1['url']) . '" alt="' . esc_attr($user_img1['alt']) . '" />';
                        } else {
                            echo '<img src="' . esc_url($user_img1['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                        }
                    }
                    ?>
                    <div class="testimonial__page-item-bottom-name">
                        <h5>
                            <?php echo esc_html($settings['user_title']); ?>
                        </h5>
                        <span>
                            <?php echo esc_html($settings['user_subtitle']); ?>
                        </span>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ('design-2' === $settings['select_design'] && !empty($settings['testimonial_items'])): ?>
            <div class="testimonial__one-pagination swiper gallery-thumbs">
                <div class="swiper-wrapper">
                    <?php foreach ($settings['testimonial_items'] as $slide): ?>
                        <div class="swiper-slide">
                            <div class="testimonial__one-pagination-item swiper-slide-container">
                                <img src="<?php echo esc_url($slide['author_image']['url']) ?>" alt="avatar-image">
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="swiper gallery-top">
                <div class="swiper-wrapper">
                    <?php foreach ($settings['testimonial_items'] as $slide): ?>
                        <div class="swiper-slide">
                            <div class="swiper-slide-container">
                                <div class="testimonial__one-item">
                                    <div class="testimonial__one-item-review">
                                        <h5>
                                            <?php echo esc_html($slide['service_type']); ?>
                                        </h5>
                                        <div class="testimonial__one-item-review-rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                    </div>
                                    <p>
                                        <?php echo esc_html($slide['authors_description']); ?>
                                    </p>
                                    <div class="testimonial__one-item-bottom">
                                        <i class="flaticon-quote-1"></i>
                                        <div class="testimonial__one-item-bottom-name">
                                            <h4>
                                                <?php echo esc_html($slide['author_title']); ?>
                                            </h4>
                                            <span>
                                                <?php echo esc_html($slide['authors_subtitle']); ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

        <?php endif; ?>


        <?php if ('design-3' === $settings['select_design'] && !empty($settings['testimonial_items'])): ?>

            <div class="testimonial__two-left">
                <div class="swiper testimonial__slider">
                    <div class="swiper-wrapper">

                        <?php foreach ($settings['testimonial_items'] as $slide): ?>
                            <div class="testimonial__two-item swiper-slide">
                                <div class="testimonial__two-item-inner">
                                    <div class="testimonial__two-item-inner-client">
                                        <h4>
                                            <?php echo esc_html($slide['author_title']); ?>
                                        </h4>
                                        <p>
                                            <?php echo esc_html($slide['authors_description']); ?>
                                        </p>
                                    </div>
                                    <div class="testimonial__two-item-inner-reviews">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </div>
                                    <div class="testimonial__two-item-inner-avatar">
                                        <img src="<?php echo esc_url($slide['author_image']['url']) ?>" alt="avatar-shape">
                                        <div class="quote">
                                            <i class="flaticon-quote"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial__two-item-bottom">
                                    <span>
                                        <?php echo esc_html($slide['authors_subtitle']); ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>

                    </div>
                </div>
                <div class="testimonial-pagination"></div>
            </div>

        <?php endif; ?>

        <?php if ('design-4' === $settings['select_design'] && !empty($settings['testimonial_items'])): ?>
            <div class="request__quote-page-right">
                <div class="swiper request__quote-slider">
                    <div class="swiper-wrapper">

                        <?php foreach ($settings['testimonial_items'] as $slide): ?>
                            <div class="request__quote-page-right-item swiper-slide">
                                <div class="request__quote-page-right-item-icon">
                                    <i class="flaticon-quote"></i>
                                </div>
                                <h5>
                                    <?php echo esc_html($slide['authors_description']); ?>
                                </h5>
                                <div class="request__quote-page-right-item-bottom">
                                    <img src="<?php echo esc_url($slide['author_image']['url']) ?>" alt="quote-image">
                                    <div class="request__quote-page-right-item-bottom-name">
                                        <h4>
                                            <?php echo esc_html($slide['author_title']); ?>
                                        </h4>
                                        <span>
                                            <?php echo esc_html($slide['authors_subtitle']); ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>

                    </div>
                </div>
                <div class="request-pagination"></div>
            </div>

        <?php endif; ?>

        <?php
    }
}

Plugin::instance()->widgets_manager->register(new Testimonial_Noxiy);